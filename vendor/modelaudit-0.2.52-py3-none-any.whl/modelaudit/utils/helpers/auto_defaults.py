"""Automatic default configuration utilities for CLI behavior."""

import os
import re
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

_AWS_REGION_HOST_PART = r"[a-z][a-z0-9]*(?:-[a-z0-9]+)+-\d"
_AWS_S3_DNS_SUFFIX = (
    r"(?:amazonaws\.com(?:\.cn)?|amazonaws\.eu|c2s\.ic\.gov|sc2s\.sgov\.gov|cloud\.adc-e\.uk|csp\.hci\.ic\.gov)"
)
_S3_PATH_STYLE_HTTPS_HOST_RE = re.compile(
    rf"^s3(?:[.-]{_AWS_REGION_HOST_PART}|\.dualstack\.{_AWS_REGION_HOST_PART})?\.{_AWS_S3_DNS_SUFFIX}$"
)
_S3_VIRTUAL_HOSTED_HTTPS_HOST_RE = re.compile(
    rf"^.+\.s3(?:[.-]{_AWS_REGION_HOST_PART}|\.dualstack\.{_AWS_REGION_HOST_PART})?\.{_AWS_S3_DNS_SUFFIX}$"
)
_S3_FIPS_PATH_STYLE_HTTPS_HOST_RE = re.compile(
    rf"^s3-fips(?:[.-]{_AWS_REGION_HOST_PART}|\.dualstack\.{_AWS_REGION_HOST_PART})\.{_AWS_S3_DNS_SUFFIX}$"
)
_S3_FIPS_VIRTUAL_HOSTED_HTTPS_HOST_RE = re.compile(
    rf"^.+\.s3-fips(?:[.-]{_AWS_REGION_HOST_PART}|\.dualstack\.{_AWS_REGION_HOST_PART})\.{_AWS_S3_DNS_SUFFIX}$"
)
_S3_ACCELERATE_VIRTUAL_HOSTED_HTTPS_HOST_RE = re.compile(r"^.+\.s3-accelerate(?:\.dualstack)?\.amazonaws\.com$")


def _get_hostname(url: str) -> str:
    """Extract and normalize the hostname from a URL."""
    try:
        return (urlparse(url).hostname or "").casefold().rstrip(".")
    except Exception:
        return ""


def _get_scheme(url: str) -> str:
    """Extract and normalize the URL scheme."""
    try:
        return urlparse(url).scheme.casefold()
    except Exception:
        return ""


def _has_valid_https_authority(url: str) -> bool:
    try:
        parsed = urlparse(url)
        return parsed.username is None and parsed.password is None and parsed.port in {None, 443}
    except ValueError:
        return False


def _is_s3_https_host(hostname: str) -> bool:
    return bool(
        _S3_PATH_STYLE_HTTPS_HOST_RE.fullmatch(hostname)
        or _S3_VIRTUAL_HOSTED_HTTPS_HOST_RE.fullmatch(hostname)
        or _S3_FIPS_PATH_STYLE_HTTPS_HOST_RE.fullmatch(hostname)
        or _S3_FIPS_VIRTUAL_HOSTED_HTTPS_HOST_RE.fullmatch(hostname)
        or _S3_ACCELERATE_VIRTUAL_HOSTED_HTTPS_HOST_RE.fullmatch(hostname)
    )


def _is_gcs_https_host(hostname: str) -> bool:
    return hostname in {"storage.googleapis.com", "storage.cloud.google.com"} or hostname.endswith(
        ".storage.googleapis.com"
    )


def _is_r2_https_host(hostname: str) -> bool:
    return hostname.endswith(".r2.cloudflarestorage.com")


def detect_input_type(path: str) -> str:
    """Detect the type of input path.

    Returns:
        One of: 'cloud_s3', 'cloud_gcs', 'cloud_azure', 'huggingface', 'pytorch_hub',
                'mlflow', 'jfrog', 'local_file', 'local_directory'
    """
    # Cloud storage detection
    hostname = _get_hostname(path)
    scheme = _get_scheme(path)
    valid_https = scheme == "https" and _has_valid_https_authority(path)
    if scheme in {"s3", "r2"} or (valid_https and (_is_s3_https_host(hostname) or _is_r2_https_host(hostname))):
        return "cloud_s3"
    if scheme in {"gs", "gcs"} or (valid_https and _is_gcs_https_host(hostname)):
        return "cloud_gcs"
    if scheme == "az" or (valid_https and hostname.endswith(".blob.core.windows.net")):
        return "cloud_azure"

    # HuggingFace detection
    if path.startswith(("hf://", "https://huggingface.co/", "https://hf.co/")):
        return "huggingface"

    # PyTorch Hub detection
    if (hostname == "pytorch.org" and "/hub/" in path) or path.startswith("pytorch.org/hub/"):
        return "pytorch_hub"

    # MLflow detection
    if path.startswith("models:/"):
        return "mlflow"

    # JFrog detection
    if hostname.endswith(".jfrog.io") or hostname == "jfrog.io" or "/artifactory/" in path:
        return "jfrog"

    # Local path detection
    if os.path.exists(path):
        return "local_directory" if os.path.isdir(path) else "local_file"

    # Default to local file for non-existent paths (will be handled by validation)
    return "local_file"


def detect_file_size(path: str) -> int:
    """Detect file size in bytes. Returns 0 if not a local file or can't determine size."""
    try:
        if os.path.isfile(path):
            return os.path.getsize(path)
        elif os.path.isdir(path):
            # Rough estimate of directory size
            total_size = 0
            for root, _dirs, files in os.walk(path):
                for file in files:
                    try:
                        file_path = os.path.join(root, file)
                        total_size += os.path.getsize(file_path)
                    except OSError:
                        continue
            return total_size
    except OSError:
        return 0
    return 0


def detect_tty_capabilities() -> dict[str, bool]:
    """Detect terminal capabilities for UI decisions."""
    return {
        "is_tty": sys.stdout.isatty(),
        "colors_supported": sys.stdout.isatty() and not os.getenv("NO_COLOR"),
        "spinner_supported": sys.stdout.isatty(),
    }


def detect_ci_environment() -> bool:
    """Detect if running in CI environment."""
    ci_indicators = [
        "CI",
        "CONTINUOUS_INTEGRATION",
        "BUILD_NUMBER",
        "GITHUB_ACTIONS",
        "GITLAB_CI",
        "JENKINS_URL",
        "TRAVIS",
        "CIRCLECI",
        "BUILDKITE",
    ]
    return any(os.getenv(var) for var in ci_indicators)


def generate_auto_defaults(paths: list[str]) -> dict[str, Any]:
    """Generate automatic defaults based on input analysis.

    Args:
        paths: List of input paths to analyze

    Returns:
        Dictionary of automatic default settings
    """
    if not paths:
        return {}

    # Analyze all paths
    input_types = [detect_input_type(path) for path in paths]
    file_sizes = [detect_file_size(path) for path in paths]
    max_file_size = max(file_sizes) if file_sizes else 0

    tty_caps = detect_tty_capabilities()
    is_ci = detect_ci_environment()

    # Generate defaults
    use_cache = _should_use_cache(input_types)
    defaults = {
        # Progress settings
        "show_progress": _should_show_progress(input_types, max_file_size, tty_caps, is_ci),
        "large_model_support": max_file_size > (1024 * 1024 * 1024),  # >1GB
        # Caching settings
        "use_cache": use_cache,
        # Download settings
        "selective_download": _should_use_selective_download(input_types),
        "stream_analysis": max_file_size > (10 * 1024 * 1024 * 1024),  # >10GB
        # File processing settings
        "skip_non_model_files": not _has_strict_mode_inputs(input_types),
        # Timeout settings
        "timeout": _calculate_auto_timeout(input_types, max_file_size),
        # Size limits
        "max_file_size": _calculate_auto_size_limit(input_types),
        # Output settings
        "format": "json" if is_ci else "text",
        "colors": tty_caps["colors_supported"] and not is_ci,
        "verbose": False,  # Keep explicit control
    }

    # Only set cache_dir if caching is enabled
    if use_cache:
        defaults["cache_dir"] = _get_default_cache_dir()

    return defaults


def _should_show_progress(input_types: list[str], max_size: int, tty_caps: dict[str, bool], is_ci: bool) -> bool:
    """Determine if progress should be shown by default."""
    if is_ci or not tty_caps["is_tty"]:
        return False

    # Show progress for cloud operations or large files
    has_cloud = any(t.startswith("cloud_") for t in input_types)
    has_remote = any(t in ["huggingface", "pytorch_hub", "mlflow", "jfrog"] for t in input_types)
    is_large = max_size > (100 * 1024 * 1024)  # >100MB

    return has_cloud or has_remote or is_large


def _should_use_cache(input_types: list[str]) -> bool:
    """Determine if caching should be enabled by default."""
    # Enable caching for any remote/cloud operations
    remote_types = ["cloud_s3", "cloud_gcs", "cloud_azure", "huggingface", "pytorch_hub", "mlflow", "jfrog"]
    return any(t in remote_types for t in input_types)


def _get_default_cache_dir() -> str:
    """Get default cache directory."""
    return str(Path.home() / ".modelaudit" / "cache")


def _should_use_selective_download(input_types: list[str]) -> bool:
    """Determine if selective download should be used."""
    # Remote registries benefit from server-side filtering to avoid downloading
    # entire model trees by default. Strict mode can still override this later.
    return any(t in ["cloud_s3", "cloud_gcs", "cloud_azure", "huggingface", "jfrog"] for t in input_types)


def _has_strict_mode_inputs(input_types: list[str]) -> bool:
    """Determine if inputs suggest strict mode should be default."""
    # Local directories might have mixed file types, so don't be strict by default
    return any(t == "local_directory" for t in input_types)


def _calculate_auto_timeout(input_types: list[str], max_size: int) -> int:
    """Calculate timeout based on input characteristics."""
    base_timeout = 3600  # 1 hour default

    # Increase timeout for cloud operations
    if any(t.startswith("cloud_") for t in input_types):
        base_timeout *= 2  # 2 hours for cloud

    # Increase timeout for very large files
    if max_size > (10 * 1024 * 1024 * 1024):  # >10GB
        base_timeout *= 3  # 3 hours for very large files
    elif max_size > (1 * 1024 * 1024 * 1024):  # >1GB
        base_timeout = int(base_timeout * 1.5)  # 1.5 hours for large files

    return base_timeout


def _calculate_auto_size_limit(input_types: list[str]) -> int:
    """Calculate size limits based on input type."""
    # No limit by default (0 = unlimited)
    if any(t.startswith("cloud_") for t in input_types):
        # 50GB limit for cloud to prevent runaway downloads
        return 50 * 1024 * 1024 * 1024

    # No limits for local files
    return 0


def apply_auto_overrides(user_args: dict[str, Any], auto_defaults: dict[str, Any]) -> dict[str, Any]:
    """Apply automatic defaults while respecting user overrides.

    Args:
        user_args: User-provided arguments (non-None values)
        auto_defaults: Automatic defaults from detection

    Returns:
        Final configuration with automatic defaults + user overrides
    """
    config = auto_defaults.copy()

    # Apply user overrides for any non-None values
    for key, value in user_args.items():
        if value is not None:
            config[key] = value

    # If caching is disabled, remove cache_dir to ensure cleanup happens
    if not config.get("use_cache", True):
        config.pop("cache_dir", None)

    return config


def parse_size_string(size_str: str) -> int:
    """Parse size string like '10GB', '500MB' into bytes.

    Args:
        size_str: Size string with optional unit (B, KB, MB, GB, TB)

    Returns:
        Size in bytes

    Raises:
        ValueError: If size string is invalid
    """
    if not size_str:
        return 0

    size_str = size_str.upper().strip()

    # Handle raw numbers (assume bytes)
    if size_str.isdigit():
        return int(size_str)

    # Parse with units (process longest units first to avoid conflicts)
    units = [
        ("TB", 1024**4),
        ("GB", 1024**3),
        ("MB", 1024**2),
        ("KB", 1024),
        ("B", 1),
    ]

    for unit, multiplier in units:
        if size_str.endswith(unit):
            try:
                number_part = size_str[: -len(unit)]
                return int(float(number_part) * multiplier)
            except ValueError:
                break

    raise ValueError(f"Invalid size format: {size_str}. Use format like '10GB', '500MB', etc.")
