"""Scanner for raw PyTorch binary model files (.bin, .pt)."""

import math
import os
import re
import struct
from typing import Any, ClassVar, Literal

from modelaudit.detectors.suspicious_symbols import (
    BINARY_CODE_PATTERNS,
    EXECUTABLE_SIGNATURES,
)

from ..core_results import mark_operational_scan_error
from ..scanner_results import mark_inconclusive_scan_result
from .base import BaseScanner, CheckStatus, IssueSeverity, ScanResult, logger


class PyTorchBinaryScanner(BaseScanner):
    """Scanner for raw PyTorch binary tensor files (.bin)"""

    name = "pytorch_binary"
    description = "Scans PyTorch binary tensor files for suspicious patterns"
    supported_extensions: ClassVar[list[str]] = [".bin"]
    MAX_EXECUTABLE_SIGNATURE_FINDINGS: ClassVar[int] = 10
    SHEBANG_CONTEXT_BYTES: ClassVar[int] = 50
    MACHO_HEADER_LAYOUTS: ClassVar[dict[bytes, tuple[Literal["big", "little"], int]]] = {
        b"\xfe\xed\xfa\xce": ("big", 28),
        b"\xce\xfa\xed\xfe": ("little", 28),
        b"\xfe\xed\xfa\xcf": ("big", 32),
        b"\xcf\xfa\xed\xfe": ("little", 32),
    }
    SECURITY_CODE_REGEX_MAX_MATCH_BYTES: ClassVar[int] = len(b"ctypes.windll.LoadLibrary(") + 5 * 8
    SECURITY_CODE_PATTERNS: ClassVar[frozenset[bytes]] = frozenset(
        {
            b"eval(",
            b"exec(",
            b"__import__",
            b"execfile(",
            b"os.system",
            b"subprocess.call",
            b"subprocess.Popen",
            b"socket.socket",
            b"ctypes.CDLL",
            b"ctypes.cdll",
            b"ctypes.windll",
            b"ctypes.WinDLL",
            b"ffi.dlopen",
            b"dlopen(",
            b"LoadLibrary",
            b"posix\nsystem",
            b"posix\npopen",
            b"nt\nsystem",
            b"nt\npopen",
        }
    )
    SECURITY_CODE_REGEX_PATTERNS: ClassVar[tuple[tuple[bytes, re.Pattern[bytes]], ...]] = (
        (b"eval(", re.compile(rb"(?<![\w.])eval[ \t\r\n]{0,8}\(")),
        (b"exec(", re.compile(rb"(?<![\w.])exec[ \t\r\n]{0,8}\(")),
        (b"__import__", re.compile(rb"(?<![\w.])__import__[ \t\r\n]{0,8}\(")),
        (b"execfile(", re.compile(rb"(?<![\w.])execfile[ \t\r\n]{0,8}\(")),
        (
            b"os.system",
            re.compile(rb"(?<![\w.])os[ \t\r\n]{0,8}\.[ \t\r\n]{0,8}system[ \t\r\n]{0,8}\("),
        ),
        (
            b"subprocess.call",
            re.compile(rb"(?<![\w.])subprocess[ \t\r\n]{0,8}\.[ \t\r\n]{0,8}call[ \t\r\n]{0,8}\("),
        ),
        (
            b"subprocess.Popen",
            re.compile(rb"(?<![\w.])subprocess[ \t\r\n]{0,8}\.[ \t\r\n]{0,8}Popen[ \t\r\n]{0,8}\("),
        ),
        (
            b"socket.socket",
            re.compile(rb"(?<![\w.])socket[ \t\r\n]{0,8}\.[ \t\r\n]{0,8}socket[ \t\r\n]{0,8}\("),
        ),
        (
            b"ctypes.CDLL",
            re.compile(rb"(?<![\w.])ctypes[ \t\r\n]{0,8}\.[ \t\r\n]{0,8}CDLL[ \t\r\n]{0,8}\("),
        ),
        (
            b"ctypes.cdll",
            re.compile(
                rb"(?<![\w.])ctypes[ \t\r\n]{0,8}\.[ \t\r\n]{0,8}cdll"
                rb"[ \t\r\n]{0,8}\.[ \t\r\n]{0,8}LoadLibrary[ \t\r\n]{0,8}\("
            ),
        ),
        (
            b"ctypes.windll",
            re.compile(
                rb"(?<![\w.])ctypes[ \t\r\n]{0,8}\.[ \t\r\n]{0,8}windll"
                rb"[ \t\r\n]{0,8}\.[ \t\r\n]{0,8}LoadLibrary[ \t\r\n]{0,8}\("
            ),
        ),
        (
            b"ctypes.WinDLL",
            re.compile(rb"(?<![\w.])ctypes[ \t\r\n]{0,8}\.[ \t\r\n]{0,8}WinDLL[ \t\r\n]{0,8}\("),
        ),
        (
            b"ffi.dlopen",
            re.compile(rb"(?<![\w.])ffi[ \t\r\n]{0,8}\.[ \t\r\n]{0,8}dlopen[ \t\r\n]{0,8}\("),
        ),
        (b"dlopen(", re.compile(rb"(?<![\w.])dlopen[ \t\r\n]{0,8}\(")),
        (b"LoadLibrary", re.compile(rb"(?<![\w.])LoadLibrary[ \t\r\n]{0,8}\(")),
    )
    SECURITY_CODE_REGEX_PATTERN_LABELS: ClassVar[frozenset[bytes]] = frozenset(
        {
            b"eval(",
            b"exec(",
            b"__import__",
            b"execfile(",
            b"os.system",
            b"subprocess.call",
            b"subprocess.Popen",
            b"socket.socket",
            b"ctypes.CDLL",
            b"ctypes.cdll",
            b"ctypes.windll",
            b"ctypes.WinDLL",
            b"ffi.dlopen",
            b"dlopen(",
            b"LoadLibrary",
        }
    )

    def __init__(self, config: dict[str, Any] | None = None):
        super().__init__(config)
        # Get blacklist patterns from config
        self.blacklist_patterns = self.config.get("blacklist_patterns") or []

    def _is_nested_archive_member(self) -> bool:
        """Return True when this scan is running on an extracted archive member."""
        try:
            return int(self.config.get("_archive_depth", 0)) > 0
        except (TypeError, ValueError):
            return False

    @classmethod
    def can_handle(cls, path: str) -> bool:
        """Check if this scanner can handle the given path"""
        if not os.path.isfile(path):
            return False

        # Check file extension
        ext = os.path.splitext(path)[1].lower()
        if ext not in cls.supported_extensions:
            return False

        # Check if it's actually a pytorch binary file
        try:
            from modelaudit.utils.file.detection import detect_file_format, validate_file_type

            file_format = detect_file_format(path)

            # Validate file type for security, but be permissive for .bin files
            # since they can contain various formats of legitimate binary data
            if not validate_file_type(path):
                # File type validation failed - log but don't reject immediately
                # for .bin files since they can contain arbitrary binary data
                logger.warning(f"File type validation failed for .bin file: {path}")
                # Continue to check if it's still a valid pytorch_binary format

            return file_format == "pytorch_binary"
        except OSError:
            return True
        except Exception:
            return False

    @staticmethod
    def _is_unreadable_path_result(result: ScanResult) -> bool:
        return any(check.name == "Path Readable" and check.status == CheckStatus.FAILED for check in result.checks)

    @staticmethod
    def _finish_read_failure(result: ScanResult, path: str, error: OSError) -> ScanResult:
        mark_inconclusive_scan_result(result, "pytorch_binary_read_failed")
        mark_operational_scan_error(result, "pytorch_binary_read_failed")
        result.add_check(
            name="Binary File Read",
            passed=False,
            message=f"Unable to read binary file: {error!s}",
            severity=IssueSeverity.INFO,
            location=path,
            details={
                "exception": str(error),
                "exception_type": type(error).__name__,
                "analysis_incomplete": True,
                "scan_outcome_reason": "pytorch_binary_read_failed",
            },
        )
        result.finish(success=False)
        return result

    def scan(self, path: str) -> ScanResult:
        """Scan a PyTorch binary file for suspicious patterns"""
        # Check if path is valid
        path_check_result = self._check_path(path)
        if path_check_result:
            if self._is_unreadable_path_result(path_check_result):
                return self._finish_read_failure(
                    self._create_result(),
                    path,
                    PermissionError(f"Path is not readable: {path}"),
                )
            return path_check_result

        size_check = self._check_size_limit(path)
        if size_check:
            return size_check

        result = self._create_result()
        file_size = self.get_file_size(path)
        result.metadata["file_size"] = file_size

        # Add file integrity check for compliance
        self.add_file_integrity_check(path, result)

        try:
            self.current_file_path = path

            # Check for suspiciously small files
            if file_size < 100 and not self._is_nested_archive_member():
                result.add_check(
                    name="File Size Validation",
                    passed=False,
                    message=f"Suspiciously small binary file: {file_size} bytes",
                    severity=IssueSeverity.INFO,
                    location=path,
                    details={"file_size": file_size},
                    rule_code="S902",
                )
            else:
                result.add_check(
                    name="File Size Validation",
                    passed=True,
                    message=("Nested binary member size is accepted" if file_size < 100 else "File size is reasonable"),
                    location=path,
                    details={
                        "file_size": file_size,
                        "archive_depth": self.config.get("_archive_depth", 0),
                    },
                    rule_code=None,  # Passing check
                )
            # Read file in chunks to look for suspicious patterns
            bytes_scanned = 0
            chunk_size = 1024 * 1024  # 1MB chunks
            previous_chunk_tail = b""
            chunk_overlap = self._get_chunk_overlap_size(chunk_size)
            reported_executable_signatures: set[tuple[str, int]] = set()
            executable_findings_reported = 0

            with open(path, "rb") as f:
                while True:
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break

                    bytes_scanned += len(chunk)
                    chunk_offset = bytes_scanned - len(chunk)
                    scan_window = previous_chunk_tail + chunk
                    window_offset = chunk_offset - len(previous_chunk_tail)
                    overlap_prefix_len = len(previous_chunk_tail)

                    # Check for embedded Python code patterns
                    self._check_for_code_patterns(
                        scan_window,
                        result,
                        window_offset,
                        overlap_prefix_len=overlap_prefix_len,
                    )

                    # Check for blacklisted patterns
                    if self.blacklist_patterns:
                        self._check_for_blacklist_patterns(
                            scan_window,
                            result,
                            window_offset,
                            overlap_prefix_len=overlap_prefix_len,
                        )

                    # Check for executable file signatures
                    if executable_findings_reported < self.MAX_EXECUTABLE_SIGNATURE_FINDINGS:
                        executable_findings_reported += self._check_for_executable_signatures(
                            scan_window,
                            result,
                            window_offset,
                            file_size=file_size,
                            reported_signatures=reported_executable_signatures,
                            finding_budget=self.MAX_EXECUTABLE_SIGNATURE_FINDINGS - executable_findings_reported,
                            overlap_prefix_len=overlap_prefix_len,
                        )
                    previous_chunk_tail = chunk[-chunk_overlap:] if chunk_overlap else b""

            result.bytes_scanned = bytes_scanned

            # Check if file appears to be a valid tensor file
            self._validate_tensor_structure(path, result)

        except OSError as e:
            return self._finish_read_failure(result, path, e)
        except Exception as e:
            result.add_check(
                name="Binary File Scan",
                passed=False,
                message=f"Error scanning binary file: {e!s}",
                severity=IssueSeverity.CRITICAL,
                location=path,
                details={"exception": str(e), "exception_type": type(e).__name__},
            )
            result.finish(success=False)
            return result

        result.finish(success=not result.has_errors)
        return result

    def _get_chunk_overlap_size(self, chunk_size: int) -> int:
        """Return the number of trailing bytes to carry into the next chunk scan."""
        longest_pattern = max(
            [
                self.SHEBANG_CONTEXT_BYTES,
                self.SECURITY_CODE_REGEX_MAX_MATCH_BYTES + 1,
                *(len(pattern) for pattern in BINARY_CODE_PATTERNS),
                *(len(pattern.encode("utf-8")) for pattern in (self.blacklist_patterns or []) if pattern),
                *(len(signature) for signature in EXECUTABLE_SIGNATURES),
            ]
        )
        return max(0, min(chunk_size - 1, longest_pattern - 1))

    def _check_for_code_patterns(
        self,
        chunk: bytes,
        result: ScanResult,
        offset: int,
        *,
        overlap_prefix_len: int = 0,
    ) -> None:
        """Check for patterns that might indicate embedded code"""
        found_suspicious = False
        reported_matches: set[tuple[bytes, int]] = set()

        def add_pattern_finding(
            pattern: bytes,
            pos: int,
            *,
            end_pos: int | None = None,
            severity: IssueSeverity | None = None,
        ) -> None:
            nonlocal found_suspicious
            if (end_pos if end_pos is not None else pos + len(pattern)) <= overlap_prefix_len:
                return
            absolute_offset = offset + pos
            match_key = (pattern, absolute_offset)
            if match_key in reported_matches:
                return
            reported_matches.add(match_key)
            finding_severity = severity or (
                IssueSeverity.WARNING if pattern in self.SECURITY_CODE_PATTERNS else IssueSeverity.INFO
            )
            result.add_check(
                name="Embedded Code Pattern Detection",
                passed=False,
                message=f"Suspicious code pattern found: {pattern.decode('ascii', errors='ignore')}",
                rule_code="S902",
                severity=finding_severity,
                location=f"{self.current_file_path} (offset: {absolute_offset})",
                details={
                    "pattern": pattern.decode("ascii", errors="ignore"),
                    "offset": absolute_offset,
                    "pattern_confidence": (
                        "high" if finding_severity == IssueSeverity.WARNING else "context_dependent"
                    ),
                },
            )
            found_suspicious = True

        for pattern, regex in self.SECURITY_CODE_REGEX_PATTERNS:
            for match in regex.finditer(chunk):
                add_pattern_finding(pattern, match.start(), end_pos=match.end(), severity=IssueSeverity.WARNING)
                break

        for pattern in BINARY_CODE_PATTERNS:
            search_start = 0
            while True:
                pos = chunk.find(pattern, search_start)
                if pos == -1:
                    break
                search_start = pos + 1
                if (
                    pattern in self.SECURITY_CODE_REGEX_PATTERN_LABELS
                    and pos > 0
                    and (chunk[pos - 1 : pos].isalnum() or chunk[pos - 1 : pos] == b"_")
                ):
                    continue
                add_pattern_finding(
                    pattern,
                    pos,
                    severity=(IssueSeverity.INFO if pattern in self.SECURITY_CODE_REGEX_PATTERN_LABELS else None),
                )
                break

        if not found_suspicious and offset == 0:  # Only record success on first chunk
            result.add_check(
                name="Embedded Code Pattern Detection",
                passed=True,
                message="No suspicious code patterns detected",
                location=self.current_file_path,
                rule_code=None,  # Passing check
            )

    def _check_for_blacklist_patterns(
        self,
        chunk: bytes,
        result: ScanResult,
        offset: int,
        *,
        overlap_prefix_len: int = 0,
    ) -> None:
        """Check for blacklisted patterns in the binary data"""
        found_blacklisted = False
        for pattern in self.blacklist_patterns or []:
            pattern_bytes = pattern.encode("utf-8")
            if not pattern_bytes:
                continue

            search_start = 0
            while True:
                pos = chunk.find(pattern_bytes, search_start)
                if pos == -1:
                    break
                search_start = pos + 1
                if pos + len(pattern_bytes) <= overlap_prefix_len:
                    continue
                result.add_check(
                    name="Blacklist Pattern Check",
                    passed=False,
                    message=f"Blacklisted pattern found: {pattern}",
                    severity=IssueSeverity.CRITICAL,
                    location=f"{self.current_file_path} (offset: {offset + pos})",
                    rule_code="S1001",
                    details={
                        "pattern": pattern,
                        "offset": offset + pos,
                    },
                )
                found_blacklisted = True
                break

        if not found_blacklisted and offset == 0:  # Only record success on first chunk
            result.add_check(
                name="Blacklist Pattern Check",
                passed=True,
                message="No blacklisted patterns found",
                location=self.current_file_path,
                rule_code=None,  # Passing check
            )

    def _verify_shebang_context(self, data: bytes, offset_in_chunk: int) -> bool:
        """
        Verify that a shebang pattern has the context of a real executable script.

        Real shebangs must have:
        1. Valid interpreter path after #!/
        2. Proper line ending after interpreter path
        """
        # Extract enough bytes to check full shebang line
        max_shebang_len = self.SHEBANG_CONTEXT_BYTES
        snippet = data[offset_in_chunk : offset_in_chunk + max_shebang_len]

        if len(snippet) < 10:  # Need at least #!/bin/sh
            return False

        # Valid interpreter paths
        valid_interpreters = [
            b"#!/bin/bash",
            b"#!/bin/sh",
            b"#!/usr/bin/python",
            b"#!/usr/bin/python3",
            b"#!/usr/bin/env",
            b"#!/bin/zsh",
            b"#!/bin/dash",
            b"#!/usr/bin/perl",
            b"#!/usr/bin/ruby",
        ]

        # Check if snippet matches a valid interpreter
        for interpreter in valid_interpreters:
            if snippet.startswith(interpreter):
                # Found valid interpreter - check what follows
                interp_len = len(interpreter)

                if len(snippet) <= interp_len:
                    return False

                # Get character right after interpreter
                next_char = snippet[interp_len : interp_len + 1]

                # Valid next characters: newline or whitespace before interpreter arguments.
                if next_char in (b"\n", b"\r", b" ", b"\t"):
                    return True

        return False

    def _is_valid_embedded_pe(
        self,
        data: bytes,
        offset_in_chunk: int,
        absolute_offset: int,
        *,
        file_size: int | None = None,
    ) -> bool:
        """Validate a non-leading DOS header before reporting embedded PE content."""
        if file_size is None:
            file_size = self.get_file_size(self.current_file_path)
        if absolute_offset < 0 or absolute_offset + 0x40 > file_size:
            return False

        pointer_offset = offset_in_chunk + 0x3C
        if pointer_offset + 4 <= len(data):
            pe_pointer = data[pointer_offset : pointer_offset + 4]
        else:
            try:
                with open(self.current_file_path, "rb") as f:
                    f.seek(absolute_offset + 0x3C)
                    pe_pointer = f.read(4)
            except OSError:
                return False
        if len(pe_pointer) != 4:
            return False
        pe_offset = int.from_bytes(pe_pointer, "little")
        if pe_offset < 0x40:
            return False
        if absolute_offset + pe_offset + 4 > file_size:
            return False
        signature_offset = offset_in_chunk + pe_offset
        if signature_offset + 4 <= len(data):
            return data[signature_offset : signature_offset + 4] == b"PE\x00\x00"
        try:
            with open(self.current_file_path, "rb") as f:
                f.seek(absolute_offset + pe_offset)
                return f.read(4) == b"PE\x00\x00"
        except OSError:
            return False

    def _read_embedded_header(
        self,
        data: bytes,
        offset_in_chunk: int,
        absolute_offset: int,
        header_size: int,
        *,
        file_size: int,
    ) -> bytes:
        if absolute_offset < 0 or absolute_offset + header_size > file_size:
            return b""
        if offset_in_chunk >= 0 and offset_in_chunk + header_size <= len(data):
            return data[offset_in_chunk : offset_in_chunk + header_size]
        try:
            with open(self.current_file_path, "rb") as f:
                f.seek(absolute_offset)
                return f.read(header_size)
        except OSError:
            return b""

    def _is_valid_embedded_elf(
        self,
        data: bytes,
        offset_in_chunk: int,
        absolute_offset: int,
        *,
        file_size: int,
    ) -> bool:
        """Validate a late ELF magic before reporting embedded executable content."""
        header = self._read_embedded_header(
            data,
            offset_in_chunk,
            absolute_offset,
            24,
            file_size=file_size,
        )
        if len(header) != 24 or not header.startswith(b"\x7fELF"):
            return False

        elf_class = header[4]
        byte_order = header[5]
        if elf_class not in {1, 2} or byte_order not in {1, 2} or header[6] != 1:
            return False

        endian: Literal["little", "big"] = "little" if byte_order == 1 else "big"
        object_type = int.from_bytes(header[16:18], endian)
        machine = int.from_bytes(header[18:20], endian)
        object_version = int.from_bytes(header[20:24], endian)
        return object_type in {2, 3} and machine != 0 and object_version == 1

    def _is_valid_embedded_macho(
        self,
        data: bytes,
        offset_in_chunk: int,
        absolute_offset: int,
        signature: bytes,
        *,
        file_size: int,
    ) -> bool:
        """Validate a late thin Mach-O magic before reporting executable content."""
        layout = self.MACHO_HEADER_LAYOUTS.get(signature)
        if layout is None:
            return False
        byte_order, header_size = layout
        header = self._read_embedded_header(
            data,
            offset_in_chunk,
            absolute_offset,
            header_size,
            file_size=file_size,
        )
        if len(header) != header_size or not header.startswith(signature):
            return False

        cpu_type = int.from_bytes(header[4:8], byte_order)
        file_type = int.from_bytes(header[12:16], byte_order)
        load_command_count = int.from_bytes(header[16:20], byte_order)
        load_command_bytes = int.from_bytes(header[20:24], byte_order)
        bytes_after_header = file_size - absolute_offset - header_size
        return (
            cpu_type != 0
            and 1 <= file_type <= 12
            and 1 <= load_command_count <= 65_535
            and load_command_count * 8 <= load_command_bytes <= bytes_after_header
        )

    def _check_for_executable_signatures(
        self,
        chunk: bytes,
        result: ScanResult,
        offset: int,
        *,
        file_size: int,
        reported_signatures: set[tuple[str, int]],
        finding_budget: int,
        overlap_prefix_len: int = 0,
    ) -> int:
        """Check for executable file signatures with context-aware detection"""
        from modelaudit.utils.helpers.ml_context import (
            analyze_binary_for_ml_context,
            should_ignore_executable_signature,
        )

        if finding_budget <= 0:
            return 0

        # Count patterns for density analysis
        pattern_counts: dict[bytes, tuple[list[int], str]] = {}

        # Common executable signatures
        for sig, description in EXECUTABLE_SIGNATURES.items():
            if sig.startswith(b"#!/") and sig != b"#!/":
                continue
            if sig in chunk:
                # Count all occurrences
                positions = []
                pos = 0
                while True:
                    pos = chunk.find(sig, pos)
                    if pos == -1:
                        break
                    if pos + len(sig) > overlap_prefix_len or sig == b"#!/":
                        positions.append(offset + pos)
                    pos += len(sig)

                if positions:
                    pattern_counts[sig] = (positions, description)

        if not pattern_counts:
            return 0

        ml_context = analyze_binary_for_ml_context(chunk, file_size)
        new_findings = 0

        # Process findings with context-aware filtering
        for sig, (positions, description) in pattern_counts.items():
            # Calculate pattern density more reasonably for small files
            file_size_mb = file_size / (1024 * 1024)
            # Use at least 1MB for density calculation to avoid inflated densities in small files
            effective_size_mb = max(file_size_mb, 1.0)
            pattern_density = len(positions) / effective_size_mb

            # Apply context-aware filtering
            filtered_positions = []
            ignored_count = 0

            for pos in positions:
                # For shell shebangs, verify they have valid interpreter context
                if sig.startswith(b"#!/"):
                    # Calculate position within chunk
                    pos_in_chunk = pos - offset
                    if not self._verify_shebang_context(chunk, pos_in_chunk):
                        ignored_count += 1
                        continue  # Skip - not a real shebang

                # Middle-of-file MZ pairs are common in weights; retain only
                # structurally validated embedded PE images.
                if (
                    sig == b"MZ"
                    and pos != 0
                    and not self._is_valid_embedded_pe(
                        chunk,
                        pos - offset,
                        pos,
                        file_size=file_size,
                    )
                ):
                    ignored_count += 1
                    continue

                if (
                    sig == b"\x7fELF"
                    and pos != 0
                    and not self._is_valid_embedded_elf(
                        chunk,
                        pos - offset,
                        pos,
                        file_size=file_size,
                    )
                ):
                    ignored_count += 1
                    continue

                if (
                    sig in self.MACHO_HEADER_LAYOUTS
                    and pos != 0
                    and not self._is_valid_embedded_macho(
                        chunk,
                        pos - offset,
                        pos,
                        sig,
                        file_size=file_size,
                    )
                ):
                    ignored_count += 1
                    continue

                if should_ignore_executable_signature(
                    sig,
                    pos,
                    ml_context,
                    pattern_density,
                    len(positions),
                ):
                    ignored_count += 1
                    continue

                filtered_positions.append(pos)

            # Report significant patterns that weren't filtered out
            for pos in filtered_positions:
                signature_key = (sig.hex(), pos)
                if signature_key in reported_signatures:
                    continue
                result.add_check(
                    name="Executable Signature Detection",
                    passed=False,
                    message=f"Executable signature found: {description}",
                    severity=IssueSeverity.CRITICAL,
                    location=f"{self.current_file_path} (offset: {pos})",
                    rule_code="S501",
                    details={
                        "signature": sig.hex(),
                        "description": description,
                        "offset": pos,
                        "total_found": len(positions),
                        "pattern_density_per_mb": round(pattern_density, 1),
                        "ml_context_confidence": ml_context.get("weight_confidence", 0),
                    },
                )
                reported_signatures.add(signature_key)
                new_findings += 1
                if new_findings >= finding_budget:
                    return new_findings

            # Add debug note about ignored patterns (only shown in verbose mode)
            if ignored_count > 0 and len(positions) > 5:
                from modelaudit.utils.helpers.ml_context import get_ml_context_explanation

                explanation = get_ml_context_explanation(ml_context, len(positions))
                result.add_check(
                    name="False Positive Filter",
                    passed=True,
                    message=f"Ignored {ignored_count} likely false positive {description} patterns",
                    severity=IssueSeverity.DEBUG,
                    location=f"{self.current_file_path}",
                    details={
                        "signature": sig.hex(),
                        "ignored_count": ignored_count,
                        "total_found": len(positions),
                        "pattern_density_per_mb": round(pattern_density, 1),
                        "ml_context_explanation": explanation,
                    },
                    why=f"These patterns were likely false positives in ML weight data. {explanation}",
                    rule_code=None,  # Passing check
                )

        return new_findings

    def _validate_tensor_structure(self, path: str, result: ScanResult) -> None:
        """Validate that the file appears to have valid tensor structure"""
        try:
            with open(path, "rb") as f:
                # Read first few bytes to check for common tensor patterns
                header = f.read(32)

                # Validate tensor file header patterns
                if len(header) < 8:
                    result.add_check(
                        name="Tensor File Size Validation",
                        passed=False,
                        message="File too small to be a valid tensor file",
                        severity=IssueSeverity.INFO,
                        location=self.current_file_path,
                        details={"header_size": len(header)},
                        rule_code="S703",
                    )
                    return

                # Check for IEEE 754 float patterns

                # Try to interpret first 8 bytes as double
                try:
                    value = struct.unpack("d", header[:8])[0]
                    # Validate float value is within reasonable bounds
                    if not (-1e100 < value < 1e100) or math.isnan(value):
                        result.metadata["tensor_validation"] = "unusual_float_values"
                except struct.error as e:
                    result.add_check(
                        name="Tensor Header Interpretation",
                        passed=False,
                        message="Error interpreting tensor header",
                        severity=IssueSeverity.DEBUG,
                        location=self.current_file_path,
                        details={
                            "exception": str(e),
                            "exception_type": type(e).__name__,
                        },
                        rule_code="S703",
                    )

        except OSError:
            raise
        except Exception as e:
            result.add_check(
                name="Tensor Structure Validation",
                passed=False,
                message=f"Error validating tensor structure: {e!s}",
                severity=IssueSeverity.DEBUG,
                location=self.current_file_path,
                details={"exception": str(e)},
                rule_code="S703",
            )

    def extract_metadata(self, file_path: str) -> dict[str, Any]:
        """Extract PyTorch binary metadata."""
        metadata = super().extract_metadata(file_path)

        try:
            file_size = self.get_file_size(file_path)

            # Basic binary analysis
            with open(file_path, "rb") as f:
                # Read first few KB to analyze structure
                header_data = f.read(min(8192, file_size))

                # Look for PyTorch signatures
                pytorch_signatures = [b"PK\x03\x04", b"\x93NUMPY", b"pytorch", b"torch"]
                detected_format = "pytorch_binary"

                for sig in pytorch_signatures:
                    if sig in header_data:
                        if sig == b"PK\x03\x04":
                            detected_format = "pytorch_zip"
                        elif sig == b"\x93NUMPY":
                            detected_format = "numpy_compatible"
                        break

                metadata.update(
                    {
                        "detected_format": detected_format,
                        "header_size": len(header_data),
                        "has_pytorch_signature": any(sig in header_data for sig in pytorch_signatures),
                    }
                )

                # Try to estimate tensor count from binary patterns
                tensor_markers = header_data.count(b"tensor") + header_data.count(b"Tensor")
                if tensor_markers > 0:
                    metadata["estimated_tensors"] = tensor_markers

        except Exception as e:
            metadata["extraction_error"] = str(e)

        return metadata
