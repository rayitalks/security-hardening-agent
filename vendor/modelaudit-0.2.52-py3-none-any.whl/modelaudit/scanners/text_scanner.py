"""Scanner for text-based ML files like README.md and vocab.txt."""

import ast
import hashlib
import io
import keyword
import os
import re
import token
import tokenize
from typing import Any, ClassVar
from urllib.parse import parse_qsl, urlsplit, urlunsplit

from modelaudit.core_results import mark_operational_scan_error
from modelaudit.detectors.network_comm import redact_url_for_finding
from modelaudit.detectors.secrets import SecretsDetector
from modelaudit.scanner_registry_metadata import TOKENIZER_VOCABULARY_CONTENT_FILENAMES
from modelaudit.scanner_results import INCONCLUSIVE_SCAN_OUTCOME, mark_inconclusive_scan_result
from modelaudit.scanners._evidence_redaction import redact_untrusted_error_message
from modelaudit.scanners.base import BaseScanner, CheckStatus, IssueSeverity, ScanResult

TEXT_CONTENT_SECURITY_SCAN_INCOMPLETE_REASON = "text_content_security_scan_incomplete"
TEXT_CONTENT_SECURITY_DETECTOR_FAILED_REASON = "text_content_security_detector_failed"
TEXT_CONTENT_SECURITY_FINDING_LIMIT_REASON = "text_content_security_finding_limit"
TEXT_CONTENT_SECURITY_CLASSIFICATION_LIMIT_REASON = "text_content_security_classification_limit"
DEFAULT_TEXT_CONTENT_SECURITY_SCAN_BYTES = 100 * 1024 * 1024
DEFAULT_TEXT_CONTENT_SECURITY_MAX_FINDINGS = 1024
DETECTOR_FINDING_LIMIT_TYPE = "detector_finding_limit"
FSTRING_MIDDLE_TOKEN_TYPE = getattr(token, "FSTRING_MIDDLE", None)
DOCUMENTATION_TEXT_FILENAMES = frozenset(
    {
        "license.md",
        "license.rst",
        "license.txt",
        "model_card",
        "model_card.md",
        "model_card.rst",
        "model_card.txt",
        "modelcard.md",
        "readme",
        "readme.md",
        "readme.markdown",
        "readme.rst",
        "readme.txt",
    }
)
PASSIVE_NETWORK_FINDING_TYPES = frozenset(
    {
        "cloud_storage_url",
        "domain",
        "domain_name",
        "ipv4_address",
        "ipv6_address",
        "url_detected",
    }
)
CORRELATABLE_DOCUMENTATION_NETWORK_FINDING_TYPES = PASSIVE_NETWORK_FINDING_TYPES | frozenset({"network_command"})
DOCUMENTATION_NETWORK_EVIDENCE_TRAILING_DELIMITERS = ".,;:)]}'\"`>"
DOCUMENTATION_NETWORK_EVIDENCE_LEADING_DELIMITERS = "<([{'\"`"
DOCUMENTATION_NETWORK_URL_BOUNDARY_BYTES = b" \t\r\n\"'<>`"
DOCUMENTATION_NETWORK_URL_MAX_SCHEME_BYTES = 32
DOCUMENTATION_NETWORK_DESTINATION_TOKEN_PATTERN = re.compile(rb"[^\s;&|#]+")
DOCUMENTATION_NETWORK_FINDING_SEVERITY_RANK = {
    "DEBUG": 0,
    "INFO": 1,
    "LOW": 1,
    "MEDIUM": 2,
    "WARNING": 2,
    "HIGH": 3,
    "CRITICAL": 3,
}
DOCUMENTATION_NETWORK_FINDING_PRIORITY = {
    "network_command": 40,
    "cloud_storage_url": 30,
    "url_detected": 20,
    "ipv4_address": 10,
    "ipv6_address": 10,
    "domain_name": 0,
    "domain": 0,
}
PASSIVE_DATA_TEXT_FILENAMES = frozenset({"classes.txt", "merges.txt"})
PASSIVE_DATA_TEXT_PREFIXES = ("label", "token", "vocab")
PASSIVE_DATA_SECRET_TYPES = frozenset({"Basic Auth Credentials", "Bearer Token"})
PASSIVE_DATA_BASIC_AUTH_LINE_PATTERN = re.compile(
    rb"^[ \t]*basic[ \t]+(?P<token>[A-Za-z0-9._~+/\-]{2,8192}={0,2})[ \t]*\r?$",
    re.IGNORECASE | re.MULTILINE,
)
PASSIVE_DATA_BEARER_AUTH_LINE_PATTERN = re.compile(
    rb"^[ \t]*bearer[ \t]+(?P<token>[A-Za-z0-9._~+/\-]{20,8192}={0,2})[ \t]*\r?$",
    re.IGNORECASE,
)
PASSIVE_DATA_BEARER_TOKEN_MARKER_BYTES = b"0123456789._~+/-"
TOKENIZER_VOCABULARY_FILENAMES = frozenset(TOKENIZER_VOCABULARY_CONTENT_FILENAMES)
TOKENIZER_VOCABULARY_PREFIXES = ("tokenizer_vocab", "tokenizer-vocab", "vocab")
TOKENIZER_VOCABULARY_OMITTABLE_CC_PATTERNS = frozenset({"trojan", "zombie"})
MIN_TOKENIZER_VOCABULARY_LINES = 8
MIN_TOKENIZER_VOCABULARY_TOKEN_LINE_RATIO = 0.95
MIN_STRONG_TOKENIZER_VOCABULARY_LINES = 128
MIN_STRONG_TOKENIZER_VOCABULARY_SENTINELS = 4
MIN_STRONG_TOKENIZER_VOCABULARY_SUBWORD_LINES = 4
MAX_TOKENIZER_VOCABULARY_TOKEN_BYTES = 256
MAX_TOKENIZER_VOCABULARY_CC_RETARGET_OCCURRENCES = 1024
TOKENIZER_VOCABULARY_SENTINELS = frozenset({b"[PAD]", b"[UNK]", b"[CLS]", b"[SEP]", b"[MASK]"})
TOKENIZER_VOCABULARY_SUBWORD_PREFIXES = ("##", "\u0120", "\u2581")
TOKENIZER_VOCABULARY_SUBWORD_SUFFIXES = ("</w>", "@@")
BARE_NETWORK_URL_TOKEN_PATTERN = re.compile(rb"[A-Za-z][A-Za-z0-9+.-]*://\S+")
REQUIREMENTS_RAW_URL_PATTERN = re.compile(rb"https?://\S+", re.IGNORECASE)
BARE_NETWORK_IPV4_TOKEN_PATTERN = re.compile(
    rb"(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}"
    rb"(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)"
)
BARE_NETWORK_IPV6_TOKEN_PATTERN = re.compile(rb"(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}")
BARE_NETWORK_DOMAIN_TOKEN_PATTERN = re.compile(rb"(?:[a-zA-Z0-9](?:[a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}")
BARE_NETWORK_TOKEN_PATTERNS = (
    BARE_NETWORK_URL_TOKEN_PATTERN,
    BARE_NETWORK_IPV4_TOKEN_PATTERN,
    BARE_NETWORK_IPV6_TOKEN_PATTERN,
    BARE_NETWORK_DOMAIN_TOKEN_PATTERN,
)
DOCUMENTATION_BARE_DOMAIN_TLDS = frozenset(
    {
        "ai",
        "app",
        "au",
        "ca",
        "cc",
        "cf",
        "ch",
        "cn",
        "co",
        "com",
        "de",
        "dev",
        "edu",
        "es",
        "example",
        "fr",
        "ga",
        "gov",
        "int",
        "io",
        "it",
        "jp",
        "mil",
        "ml",
        "net",
        "nl",
        "no",
        "org",
        "pw",
        "ru",
        "se",
        "tk",
        "to",
        "uk",
        "us",
        "xyz",
    }
)
MAX_TEXT_FINDING_CONTEXT_BYTES = 4096
MAX_TEXT_TRUNCATED_XML_CONTEXT_BYTES = MAX_TEXT_FINDING_CONTEXT_BYTES * 64
MAX_DOCUMENTATION_FINDING_RETARGET_OCCURRENCES = 1024
DOCUMENTATION_CODE_ASSIGNMENT_PATTERN = re.compile(
    rb"(?:^|[\r\n{[(,;])[ \t]*(?:(?:const|let|var)[ \t]+)?[A-Za-z_][A-Za-z0-9_.-]*[ \t]*="
    rb"[\s(\[{\\]{0,4096}[rubfRUBF]*[\"']?$"
)
DOCUMENTATION_CODE_LITERAL_VALUE_PREFIX_PATTERN = re.compile(
    rb"(?:^|[\r\n{[(,;])[ \t]*(?:(?:const|let|var)[ \t]+)?[A-Za-z_][A-Za-z0-9_.-]*[ \t]*="
    rb"(?=[^\r\n]{0,4096}$)[^\r\n]*[rubfRUBF]*[\"']$"
)
DOCUMENTATION_CODE_LITERAL_BLOCK_PREFIX_PATTERN = re.compile(
    rb"(?:^|[\r\n{[(,;])[ \t]*(?:(?:const|let|var)[ \t]+)?[A-Za-z_][A-Za-z0-9_.-]*[ \t]*="
    rb"(?=[^\r\n]{0,4096}$)[^\r\n]*[\[{(][ \t]*(?:#.*)?$"
)
DOCUMENTATION_CODE_RETURN_STRING_PATTERN = re.compile(
    rb"(?:^|[\r\n;{[(])[ \t]*(?:return|yield)\s+(?:[\s(\[{]{0,4096})?[rubfRUBF]*[\"']?$"
)
DOCUMENTATION_PASSIVE_HTML_URL_ATTRIBUTE_PATTERN = re.compile(
    rb"<(?:a\b[^<>]{0,4096}\bhref|img\b[^<>]{0,4096}\bsrc)\s*=\s*[\"']?$",
    re.IGNORECASE,
)
DOCUMENTATION_EXECUTABLE_HTML_URL_ATTRIBUTE_PATTERN = re.compile(
    rb"<(?:iframe\b[^<>]{0,4096}\bsrc|link\b[^<>]{0,4096}\bhref|script\b[^<>]{0,4096}\bsrc)"
    rb"\s*=\s*[\"']?$",
    re.IGNORECASE,
)
DOCUMENTATION_HTML_URL_ATTRIBUTE_PATTERN = re.compile(rb"\b(?:href|src)\s*=\s*[\"']?$", re.IGNORECASE)
DOCUMENTATION_CODE_CALL_PATTERN = re.compile(rb"\b[A-Za-z_][A-Za-z0-9_.]*\s*\([^()]{0,4096}[rubfRUBF]*[\"']$")
DOCUMENTATION_MARKDOWN_LINK_URL_PREFIX_PATTERN = re.compile(rb"!?\[[^\]\r\n]{0,4096}\]\($")
DOCUMENTATION_BIBLIOGRAPHY_ENTRY_START_PATTERN = re.compile(rb"(?im)^\s*@[A-Za-z][A-Za-z0-9_-]*\s*\{")
DOCUMENTATION_BIBLIOGRAPHY_FIELD_PREFIX_PATTERN = re.compile(
    rb"(?:^|[,{])\s*(?P<field>[A-Za-z][A-Za-z0-9_-]*)\s*=\s*(?P<delimiter>[{\"']?)[^,\r\n]{0,4096}$",
    re.IGNORECASE,
)
DOCUMENTATION_BIBLIOGRAPHY_URL_FIELD_PREFIX_PATTERN = re.compile(
    rb"(?:^|[,{])\s*url\s*=\s*(?P<delimiter>[{\"']?)\s*$",
    re.IGNORECASE,
)
DOCUMENTATION_PASSIVE_BIBLIOGRAPHY_FIELDS = frozenset(
    {
        b"abstract",
        b"address",
        b"archiveprefix",
        b"author",
        b"booktitle",
        b"copyright",
        b"doi",
        b"edition",
        b"editor",
        b"eprint",
        b"howpublished",
        b"institution",
        b"isbn",
        b"issn",
        b"journal",
        b"license",
        b"month",
        b"note",
        b"number",
        b"organization",
        b"pages",
        b"primaryclass",
        b"publisher",
        b"school",
        b"series",
        b"title",
        b"url",
        b"volume",
        b"year",
    }
)
DOCUMENTATION_MARKDOWN_PREFIX_PATTERN = re.compile(rb"(?:(?:[-*+>]|[0-9]{1,9}[.)])\s+){1,8}")
DOCUMENTATION_CONFIG_NETWORK_KEY = rb"(?:endpoint|callback|webhook)(?:s|[_-][A-Za-z0-9_.-]{1,128}|(?:url|uri)s?)?"
DOCUMENTATION_CONFIG_MAPPING_PATTERN = re.compile(
    rb"(?:^|[\s{[(,;])(?:[\"']"
    + DOCUMENTATION_CONFIG_NETWORK_KEY
    + rb"[\"']|"
    + DOCUMENTATION_CONFIG_NETWORK_KEY
    + rb")\s*:\s*(?:\[\s*)?(?:(?:\r?\n|\r)[ \t]*(?:[-*+]\s+)?)?[\"']?$",
    re.IGNORECASE,
)
DOCUMENTATION_CONFIG_MARKDOWN_MAPPING_PATTERN = re.compile(
    rb"(?:^|[\s{[(,;])(?:[\"']"
    + DOCUMENTATION_CONFIG_NETWORK_KEY
    + rb"[\"']|"
    + DOCUMENTATION_CONFIG_NETWORK_KEY
    + rb")\s*:\s*(?:\[\s*)?(?:(?:\r?\n|\r)[ \t]*(?:[-*+]\s+)?)?[\"']?$"
)
DOCUMENTATION_CONFIG_MAPPING_PREFIX_PATTERN = re.compile(
    rb"(?:^|[\s{[(,;])(?:[\"']"
    + DOCUMENTATION_CONFIG_NETWORK_KEY
    + rb"[\"']|"
    + DOCUMENTATION_CONFIG_NETWORK_KEY
    + rb")\s*:\s*(?:\[\s*)?[\"']?$",
    re.IGNORECASE,
)
DOCUMENTATION_CONFIG_LIST_MAPPING_PATTERN = re.compile(
    rb"(?:^|(?:\r?\n|\r))[ \t]*[-*+]\s+" + DOCUMENTATION_CONFIG_NETWORK_KEY + rb"\s*:\s*(?:\[\s*)?$"
)
DOCUMENTATION_CONFIG_MARKDOWN_UNQUOTED_MAPPING_PATTERN = re.compile(
    rb"(?:^|[\s{[(,;])" + DOCUMENTATION_CONFIG_NETWORK_KEY + rb"\s*:\s*(?:\[\s*)?$"
)
DOCUMENTATION_NESTED_CONFIG_OBJECT_PATTERN = re.compile(
    rb"(?:^|[\s{[(,;])[\"']?" + DOCUMENTATION_CONFIG_NETWORK_KEY + rb"[\"']?\s*(?:=|:)\s*"
    rb"\{[^{}]{0,4096}[\"']?(?:url|uri)[\"']?\s*:\s*[\"']?$",
    re.IGNORECASE,
)
DOCUMENTATION_NESTED_CONFIG_PARENT_LINE_PATTERN = re.compile(
    rb"[ \t]*[\"']?" + DOCUMENTATION_CONFIG_NETWORK_KEY + rb"[\"']?\s*:\s*",
    re.IGNORECASE,
)
DOCUMENTATION_NESTED_CONFIG_VALUE_LINE_PATTERN = re.compile(
    rb"[ \t]*(?:[-*+]\s+)?[\"']?(?:url|uri)[\"']?\s*:\s*[\"']?",
    re.IGNORECASE,
)
DOCUMENTATION_NESTED_CONFIG_LIST_ITEM_PATTERN = re.compile(
    rb"[ \t]*[-*+]\s+\S.*",
    re.IGNORECASE,
)
DOCUMENTATION_LIST_ITEM_PREFIX_PATTERN = re.compile(rb"[ \t]*[-*+]\s+")
DOCUMENTATION_CONFIG_XML_TAG_NAME = (
    rb"(?:[A-Za-z_][A-Za-z0-9_.-]*:)?(?:endpoint|callback|webhook)"
    rb"(?:[-_:][A-Za-z0-9_.-]+(?::[A-Za-z0-9_.-]+)*)?"
)
DOCUMENTATION_CONFIG_TAG_PATTERN = re.compile(
    rb"<" + DOCUMENTATION_CONFIG_XML_TAG_NAME + rb">\s*$",
    re.IGNORECASE,
)
DOCUMENTATION_CONFIG_TAG_START_PATTERN = re.compile(
    rb"<(?P<closing>/)?\s*(?P<tag>" + DOCUMENTATION_CONFIG_XML_TAG_NAME + rb")(?=[\s>/])",
    re.IGNORECASE,
)
DOCUMENTATION_CONFIG_QUOTED_VALUE_OPEN_PATTERN = re.compile(
    rb"(?:^|[\s{[(,;])(?:[\"']"
    + DOCUMENTATION_CONFIG_NETWORK_KEY
    + rb"[\"']|"
    + DOCUMENTATION_CONFIG_NETWORK_KEY
    + rb")\s*:\s*(?:\[\s*)?(?P<quote>[\"'])",
    re.IGNORECASE,
)
DOCUMENTATION_NESTED_CONFIG_OBJECT_QUOTED_VALUE_OPEN_PATTERN = re.compile(
    rb"(?:^|[\s{[(,;])[\"']?"
    + DOCUMENTATION_CONFIG_NETWORK_KEY
    + rb"[\"']?\s*(?:=|:)\s*\{[^{}\r\n]{0,4096}[\"']?(?:url|uri)[\"']?\s*:\s*(?P<quote>[\"'])",
    re.IGNORECASE,
)
DOCUMENTATION_NESTED_CONFIG_QUOTED_VALUE_LINE_PATTERN = re.compile(
    rb"[ \t]*(?:[-*+]\s+)?[\"']?(?:url|uri)[\"']?\s*:\s*(?P<quote>[\"'])",
    re.IGNORECASE,
)
DOCUMENTATION_PRIVILEGE_OPTION_WITH_ARGUMENT = (
    rb"(?:-(?:C|D|g|h|p|R|T|u)|--(?:chdir|chroot|close-from|command-timeout|group|host|other-user|"
    rb"prompt|role|type|user))"
)
DOCUMENTATION_PRIVILEGE_OPTION = (
    rb"(?:"
    + DOCUMENTATION_PRIVILEGE_OPTION_WITH_ARGUMENT
    + rb"(?:=[^\s]+|\s+[^\s]+)|--?[A-Za-z][A-Za-z0-9_-]*(?:=[^\s]+)?)"
)
DOCUMENTATION_ENV_OPTION_ARGUMENT = rb"(?:[^\s\"']+|\"[^\"\r\n]{0,4096}\"|'[^'\r\n]{0,4096}')"
DOCUMENTATION_ENV_OPTION_WITH_ARGUMENT = rb"(?:-(?:C|u)|--(?:chdir|unset))"
DOCUMENTATION_ENV_OPTION_WITHOUT_ARGUMENT = (
    rb"(?:-[0iv]{1,3}|--(?:debug|ignore-environment|list-signal-handling|null)"
    rb"|--(?:block-signal|default-signal|ignore-signal)(?:=[^\s]+)?)"
)
DOCUMENTATION_ENV_OPTION = (
    rb"(?:"
    + DOCUMENTATION_ENV_OPTION_WITH_ARGUMENT
    + rb"(?:="
    + DOCUMENTATION_ENV_OPTION_ARGUMENT
    + rb"|\s+"
    + DOCUMENTATION_ENV_OPTION_ARGUMENT
    + rb")|"
    + DOCUMENTATION_ENV_OPTION_WITHOUT_ARGUMENT
    + rb")"
)
DOCUMENTATION_ENV_ASSIGNMENT = rb"[A-Za-z_][A-Za-z0-9_]{0,127}=(?:[^\s\"']+|\"[^\"\r\n]{0,4096}\"|'[^'\r\n]{0,4096}')"
DOCUMENTATION_ENV_SPLIT_STRING_WRAPPER = (
    rb"env(?:\s+" + DOCUMENTATION_ENV_OPTION + rb"){0,8}\s+(?:-S|--split-string)(?:=|\s+)[\"']?\s*"
)
DOCUMENTATION_ENV_WRAPPER = (
    rb"(?:(?:" + DOCUMENTATION_ENV_SPLIT_STRING_WRAPPER + rb")|(?:env(?:\s+" + DOCUMENTATION_ENV_OPTION + rb"){0,8}\s+"
    rb"(?:--\s+)?(?:" + DOCUMENTATION_ENV_ASSIGNMENT + rb"\s+){0,16})"
    rb"|(?:(?:" + DOCUMENTATION_ENV_ASSIGNMENT + rb"\s+){1,16}))?"
)
DOCUMENTATION_PRIVILEGE_WRAPPER = (
    rb"(?:(?:sudo|doas)(?:\s+"
    + DOCUMENTATION_PRIVILEGE_OPTION
    + rb"){0,8}\s+(?:--\s+)?"
    + DOCUMENTATION_ENV_WRAPPER
    + rb")?"
)
DOCUMENTATION_SHELL_WRAPPERS = DOCUMENTATION_ENV_WRAPPER + DOCUMENTATION_PRIVILEGE_WRAPPER
DOCUMENTATION_TIMEOUT_OPTION = (
    rb"(?:-(?:k|s)|--(?:kill-after|signal))(?:=[^\s]+|\s+[^\s]+)"
    rb"|--(?:foreground|preserve-status|verbose)"
)
DOCUMENTATION_POSIX_LAUNCHER_WRAPPER = (
    rb"(?:(?:"
    rb"(?:command|exec|nohup)(?:\s+--)?\s+"
    rb"|time(?:\s+-[pv]+){0,2}\s+"
    rb"|timeout(?:\s+(?:" + DOCUMENTATION_TIMEOUT_OPTION + rb")){0,4}\s+"
    rb"[0-9]+(?:\.[0-9]+)?[smhd]?\s+"
    rb"|nice(?:\s+(?:-n\s+[-+]?[0-9]+|--adjustment(?:=|\s+)[-+]?[0-9]+|[-+][0-9]+))?\s+"
    rb"|setsid(?:\s+--?[A-Za-z][A-Za-z0-9_-]*(?:=[^\s]+)?){0,4}\s+"
    rb")){0,2}"
)
DOCUMENTATION_SHELL_OPTION = rb"--?[A-Za-z][A-Za-z0-9_-]*(?:=[^\s]+)?"
DOCUMENTATION_SHELL_COMMAND_OPTION = rb"-[A-Za-z]*c[A-Za-z]*"
DOCUMENTATION_COMMAND_ARRAY_SEPARATOR = rb"[\"']?\s*,\s*[\"']?"
DOCUMENTATION_CMD_OPTION = rb"/[A-Za-z](?::[^\s]+)?"
DOCUMENTATION_SHELL_INTERPRETER_WRAPPER = (
    rb"(?:(?:(?:bash|sh|zsh)(?:\s+"
    + DOCUMENTATION_SHELL_OPTION
    + rb"){0,8}\s+"
    + DOCUMENTATION_SHELL_COMMAND_OPTION
    + rb"|cmd(?:\.exe)?(?:\s+"
    + DOCUMENTATION_CMD_OPTION
    + rb"){0,8}\s+/(?:c|k)|eval)\s+[\"']?\s*)?"
)
DOCUMENTATION_SHELL_WRAPPED_COMMAND = (
    DOCUMENTATION_SHELL_WRAPPERS
    + DOCUMENTATION_POSIX_LAUNCHER_WRAPPER
    + DOCUMENTATION_SHELL_INTERPRETER_WRAPPER
    + DOCUMENTATION_SHELL_WRAPPERS
    + DOCUMENTATION_POSIX_LAUNCHER_WRAPPER
)
DOCUMENTATION_SHELL_PROMPT = rb"(?:(?:[$>#]|[A-Za-z0-9._-]+[$#>])\s*)?"
DOCUMENTATION_ROOT_PROMPT_NON_SHELL_PREFIX_PATTERN = re.compile(
    rb"^(?:[A-Za-z][A-Za-z0-9 _-]{0,31}\s*:\s+|(?:ADD|CMD|ENTRYPOINT|RUN)\b)"
)
DOCUMENTATION_INLINE_CODE_OPEN = rb"(?:`{1,3}\s*)?"
DOCUMENTATION_COMMAND_LABEL = rb"(?:[A-Za-z][A-Za-z0-9 _-]{0,31}\s*:\s*)?"
DOCUMENTATION_DOCKER_RUN_OPTION = rb"--[A-Za-z][A-Za-z0-9_-]*(?:=[^\s]+)?"
DOCUMENTATION_DOCKER_RUN = rb"(?:RUN(?:\s+" + DOCUMENTATION_DOCKER_RUN_OPTION + rb"){0,8}\s+)?"
DOCUMENTATION_COMMAND_CONTEXT = DOCUMENTATION_COMMAND_LABEL + DOCUMENTATION_DOCKER_RUN
DOCUMENTATION_SHELL_LINE_PREFIX = (
    rb"^\s*(?:(?:[-*+>]|[0-9]{1,9}[.)])\s+){0,8}"
    + DOCUMENTATION_INLINE_CODE_OPEN
    + DOCUMENTATION_SHELL_PROMPT
    + DOCUMENTATION_COMMAND_CONTEXT
)
DOCUMENTATION_COMMAND_PATH_PREFIX = rb"(?:/(?:usr/)?bin/)?(?:(?:busybox|toybox)(?:\.exe)?\s+)?"
DOCUMENTATION_DOWNLOADER_COMMAND = (
    DOCUMENTATION_COMMAND_PATH_PREFIX + rb"(?:curl|fetch|invoke-restmethod|invoke-webrequest|irm|iwr|wget)(?:\.exe)?"
)
DOCUMENTATION_COMMAND_ARRAY_PATTERN = re.compile(
    DOCUMENTATION_SHELL_LINE_PREFIX
    + rb"(?:RUN|CMD|ENTRYPOINT|command)\s*(?::|=)?\s*\[\s*[\"']?"
    + DOCUMENTATION_DOWNLOADER_COMMAND
    + rb"\b[\"']?\s*,\s*[\"']?"
    + rb"(?:$|--?[A-Za-z]|[A-Za-z][A-Za-z0-9+.-]*://|(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}|[$\\])",
    re.IGNORECASE,
)
DOCUMENTATION_SHELL_COMMAND_ARRAY_PATTERN = re.compile(
    DOCUMENTATION_SHELL_LINE_PREFIX
    + rb"(?:RUN|CMD|ENTRYPOINT|command)\s*(?::|=)?\s*\[\s*[\"']?"
    + DOCUMENTATION_COMMAND_PATH_PREFIX
    + rb"(?:bash|sh|zsh)"
    + DOCUMENTATION_COMMAND_ARRAY_SEPARATOR
    + rb"(?:"
    + DOCUMENTATION_SHELL_OPTION
    + DOCUMENTATION_COMMAND_ARRAY_SEPARATOR
    + rb"){0,8}"
    + DOCUMENTATION_SHELL_COMMAND_OPTION
    + DOCUMENTATION_COMMAND_ARRAY_SEPARATOR
    + DOCUMENTATION_POSIX_LAUNCHER_WRAPPER
    + DOCUMENTATION_DOWNLOADER_COMMAND
    + rb"\b\s+",
    re.IGNORECASE,
)
DOCUMENTATION_XARGS_DOWNLOADER_PATTERN = re.compile(
    rb"(?:" + DOCUMENTATION_SHELL_LINE_PREFIX + rb"|[;&|]\s*)xargs"
    rb"(?:\s+--?[A-Za-z][A-Za-z0-9_-]*(?:=[^\s]+)?){0,8}\s+" + DOCUMENTATION_DOWNLOADER_COMMAND + rb"\b",
    re.IGNORECASE,
)
DOCUMENTATION_FIND_EXEC_DOWNLOADER_PATTERN = re.compile(
    DOCUMENTATION_SHELL_LINE_PREFIX
    + DOCUMENTATION_SHELL_WRAPPED_COMMAND
    + rb"find\b[^\r\n]{0,4096}?\s+-(?:exec|execdir)\s+"
    + DOCUMENTATION_SHELL_WRAPPED_COMMAND
    + DOCUMENTATION_DOWNLOADER_COMMAND
    + rb"\b\s+(?:--?[A-Za-z]|[A-Za-z][A-Za-z0-9+.-]*://|(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}|[$\"'\\])",
    re.IGNORECASE,
)
DOCUMENTATION_DOCKER_ADD_PATTERN = re.compile(
    DOCUMENTATION_SHELL_LINE_PREFIX
    + rb"ADD(?:\s+--[A-Za-z][A-Za-z0-9_-]*(?:=[^\s]+)?){0,8}\s+"
    + rb"(?:$|[A-Za-z][A-Za-z0-9+.-]*://)",
)
DOCUMENTATION_DOCKER_ADD_CONTINUATION_PATTERN = re.compile(
    DOCUMENTATION_SHELL_LINE_PREFIX + rb"ADD(?:\s+--[A-Za-z][A-Za-z0-9_-]*(?:=[^\s]+)?){0,8}\s+\\$"
)
DOCUMENTATION_CERTUTIL_OPTION = rb"-[A-Za-z][A-Za-z0-9_-]*"
DOCUMENTATION_CERTUTIL_COMMAND_PATTERN = re.compile(
    DOCUMENTATION_SHELL_LINE_PREFIX
    + DOCUMENTATION_SHELL_WRAPPED_COMMAND
    + DOCUMENTATION_COMMAND_PATH_PREFIX
    + rb"certutil(?:\.exe)?"
    + rb"(?:\s+"
    + DOCUMENTATION_CERTUTIL_OPTION
    + rb"){0,8}\s+-urlcache"
    + rb"(?:\s+"
    + DOCUMENTATION_CERTUTIL_OPTION
    + rb"){0,8}\s+"
    + rb"[\"']?(?:[A-Za-z][A-Za-z0-9+.-]*://|(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,})",
    re.IGNORECASE,
)
DOCUMENTATION_NETCAT_OPTION_WITH_ARGUMENT = (
    rb"(?:-(?:e|i|p|q|s|w)|--(?:exec|interval|proxy|proxy-type|source|source-port|wait))"
    rb"(?:=[^\s]+|\s+[^\s]+)"
)
DOCUMENTATION_NETCAT_OPTION_WITHOUT_ARGUMENT = (
    rb"(?:-[46bCdDhklNnrStUuvz]+|--(?:close|listen|no-shutdown|recv-only|send-only|telnet|udp|verbose|zero))"
)
DOCUMENTATION_NETCAT_OPTION = (
    rb"(?:" + DOCUMENTATION_NETCAT_OPTION_WITH_ARGUMENT + rb"|" + DOCUMENTATION_NETCAT_OPTION_WITHOUT_ARGUMENT + rb")"
)
DOCUMENTATION_NETCAT_ENDPOINT = (
    rb"(?:\[[0-9A-Fa-f:]+\]|(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}|(?:[0-9]{1,3}\.){3}[0-9]{1,3}|localhost)"
)
DOCUMENTATION_NETWORK_PORT = (
    rb"(?:[1-9][0-9]{0,3}|[1-5][0-9]{4}|6[0-4][0-9]{3}|65[0-4][0-9]{2}|655[0-2][0-9]|6553[0-5])"
)
DOCUMENTATION_NETCAT_COMMAND = (
    DOCUMENTATION_COMMAND_PATH_PREFIX
    + rb"(?:nc|ncat|netcat)(?:\.exe)?"
    + rb"(?:\s+"
    + DOCUMENTATION_NETCAT_OPTION
    + rb"){0,8}\s+"
    + DOCUMENTATION_NETCAT_ENDPOINT
    + rb"\s+"
    + DOCUMENTATION_NETWORK_PORT
    + rb"\b"
)
DOCUMENTATION_NETCAT_COMMAND_PATTERN = re.compile(
    DOCUMENTATION_SHELL_LINE_PREFIX + DOCUMENTATION_SHELL_WRAPPED_COMMAND + DOCUMENTATION_NETCAT_COMMAND,
    re.IGNORECASE,
)
DOCUMENTATION_GIT_CLONE_OPTION_WITH_ARGUMENT = (
    rb"(?:-(?:b|c|j|o|u)|--(?:branch|config|depth|filter|jobs|origin|reference|reference-if-able|"
    rb"separate-git-dir|shallow-exclude|shallow-since|template|upload-pack))(?:=|\s+)[^\s]{1,4096}"
)
DOCUMENTATION_GIT_CLONE_OPTION = (
    rb"(?:" + DOCUMENTATION_GIT_CLONE_OPTION_WITH_ARGUMENT + rb"|-[lnqsv]+|--[A-Za-z][A-Za-z0-9_-]*(?:=[^\s]{1,4096})?)"
)
DOCUMENTATION_GIT_CLONE_DESTINATION = (
    rb"(?:[A-Za-z][A-Za-z0-9+.-]*://[^\s\"'<>]{1,4096}|(?:[A-Za-z0-9._-]+@)?"
    + DOCUMENTATION_NETCAT_ENDPOINT
    + rb":[^\s\"'<>]{1,4096})"
)
DOCUMENTATION_NETWORK_COMMAND_LINE_LIMIT = rb"(?=[^\r\n]{1,8192}(?:\r?\n)?$)"
DOCUMENTATION_GIT_CLONE_COMMAND_PATTERN = re.compile(
    DOCUMENTATION_SHELL_LINE_PREFIX
    + DOCUMENTATION_NETWORK_COMMAND_LINE_LIMIT
    + DOCUMENTATION_SHELL_WRAPPED_COMMAND
    + DOCUMENTATION_COMMAND_PATH_PREFIX
    + rb"git(?:\.exe)?\s+clone"
    rb"(?:\s+"
    + DOCUMENTATION_GIT_CLONE_OPTION
    + rb"){0,8}\s+(?:--\s+)?"
    + DOCUMENTATION_GIT_CLONE_DESTINATION
    + rb"(?:\s+[^\s;&|#]{1,4096})?(?=\s*(?:$|[;&|#]))",
    re.IGNORECASE,
)
DOCUMENTATION_SSH_OPTION_WITH_ARGUMENT = rb"-(?:B|b|c|D|E|F|I|i|J|L|l|m|O|o|p|Q|R|S|W|w)(?:=|\s+)?[^\s]{1,4096}"
DOCUMENTATION_SSH_OPTION_WITHOUT_ARGUMENT = rb"-[46AaCfGgKkMNnqsTtVvXxYy]+"
DOCUMENTATION_SSH_OPTION = (
    rb"(?:" + DOCUMENTATION_SSH_OPTION_WITH_ARGUMENT + rb"|" + DOCUMENTATION_SSH_OPTION_WITHOUT_ARGUMENT + rb")"
)
DOCUMENTATION_SSH_COMMAND_PATTERN = re.compile(
    DOCUMENTATION_SHELL_LINE_PREFIX
    + DOCUMENTATION_SHELL_WRAPPED_COMMAND
    + DOCUMENTATION_COMMAND_PATH_PREFIX
    + rb"ssh(?:\.exe)?(?:\s+"
    + DOCUMENTATION_SSH_OPTION
    + rb"){0,8}\s+(?:[A-Za-z0-9._-]+@)?"
    + DOCUMENTATION_NETCAT_ENDPOINT
    + rb"(?=\s*(?:$|[;&|<>#]))",
    re.IGNORECASE,
)
DOCUMENTATION_DOCKER_PULL_OPTION_WITH_ARGUMENT = rb"--(?:disable-content-trust|platform)(?:=|\s+)[^\s]{1,4096}"
DOCUMENTATION_DOCKER_PULL_OPTION = (
    rb"(?:" + DOCUMENTATION_DOCKER_PULL_OPTION_WITH_ARGUMENT + rb"|-[aq]+|--[A-Za-z][A-Za-z0-9_-]*(?:=[^\s]{1,4096})?)"
)
DOCUMENTATION_DOCKER_PULL_COMMAND_PATTERN = re.compile(
    DOCUMENTATION_SHELL_LINE_PREFIX + DOCUMENTATION_SHELL_WRAPPED_COMMAND + rb"docker(?:\.exe)?\s+(?:image\s+)?pull"
    rb"(?:\s+" + DOCUMENTATION_DOCKER_PULL_OPTION + rb"){0,8}\s+"
    rb"(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}(?::" + DOCUMENTATION_NETWORK_PORT + rb")?/[^\s\"'<>]{1,4096}"
    rb"(?=\s*(?:$|[;&|#]))",
    re.IGNORECASE,
)
DOCUMENTATION_INLINE_NETCAT_COMMAND_PATTERN = re.compile(
    rb"(?:^|[;&|]\s*)"
    + DOCUMENTATION_INLINE_CODE_OPEN
    + DOCUMENTATION_SHELL_PROMPT
    + DOCUMENTATION_COMMAND_CONTEXT
    + DOCUMENTATION_SHELL_WRAPPED_COMMAND
    + DOCUMENTATION_NETCAT_COMMAND,
    re.IGNORECASE,
)
DOCUMENTATION_POWERSHELL_OPTION_WITH_ARGUMENT = (
    rb"-(?:configurationname|executionpolicy|inputformat|outputformat|settingsfile|windowstyle|workingdirectory)"
    rb"(?:=[^\s]+|\s+[^\s]+)"
)
DOCUMENTATION_POWERSHELL_OPTION_WITHOUT_ARGUMENT = rb"-(?:login|mta|nologo|noexit|noninteractive|noprofile|sta)"
DOCUMENTATION_POWERSHELL_COMMAND = (
    rb"(?:powershell(?:\.exe)?|pwsh)\b"
    + rb"(?:\s+(?:"
    + DOCUMENTATION_POWERSHELL_OPTION_WITH_ARGUMENT
    + rb"|"
    + DOCUMENTATION_POWERSHELL_OPTION_WITHOUT_ARGUMENT
    + rb")){0,8}(?:\s+-(?:c|command|e|enc|encodedcommand)\b|\s+"
    + DOCUMENTATION_DOWNLOADER_COMMAND
    + rb"\b\s+)"
)
DOCUMENTATION_POWERSHELL_COMMAND_PATTERN = re.compile(
    DOCUMENTATION_SHELL_LINE_PREFIX + DOCUMENTATION_SHELL_WRAPPED_COMMAND + DOCUMENTATION_POWERSHELL_COMMAND,
    re.IGNORECASE,
)
DOCUMENTATION_INLINE_POWERSHELL_COMMAND_PATTERN = re.compile(
    rb"(?:^|[;&|]\s*)"
    + DOCUMENTATION_INLINE_CODE_OPEN
    + DOCUMENTATION_SHELL_PROMPT
    + DOCUMENTATION_COMMAND_CONTEXT
    + DOCUMENTATION_SHELL_WRAPPED_COMMAND
    + DOCUMENTATION_POWERSHELL_COMMAND,
    re.IGNORECASE,
)
DOCUMENTATION_SHELL_COMMAND_PATTERN = re.compile(
    DOCUMENTATION_SHELL_LINE_PREFIX + DOCUMENTATION_SHELL_WRAPPED_COMMAND + rb"(?:(?:\$\(|`)\s*)?"
    rb"(?:" + DOCUMENTATION_DOWNLOADER_COMMAND + rb"\b\s+"
    rb"(?:--?[A-Za-z]|[A-Za-z][A-Za-z0-9+.-]*://|(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}|[$\"'\\])"
    rb")",
    re.IGNORECASE,
)
DOCUMENTATION_INLINE_SHELL_COMMAND_PATTERN = re.compile(
    rb"(?:^|[;&|]\s*)"
    + DOCUMENTATION_INLINE_CODE_OPEN
    + DOCUMENTATION_SHELL_PROMPT
    + DOCUMENTATION_COMMAND_CONTEXT
    + DOCUMENTATION_SHELL_WRAPPED_COMMAND
    + rb"(?:(?:\$\(|`)\s*)?(?:"
    + DOCUMENTATION_DOWNLOADER_COMMAND
    + rb"\b\s+"
    rb"(?:--?[A-Za-z]|[A-Za-z][A-Za-z0-9+.-]*://|(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}|[$\"'\\]|$)"
    rb")",
    re.IGNORECASE,
)
DOCUMENTATION_SHELL_SUBSTITUTION_PATTERN = re.compile(
    rb"(?:\$\(|`)\s*" + DOCUMENTATION_SHELL_WRAPPED_COMMAND + DOCUMENTATION_DOWNLOADER_COMMAND + rb"\b\s+"
    rb"(?:--?[A-Za-z]|[A-Za-z][A-Za-z0-9+.-]*://|(?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,}|[$\"'\\]|$)",
    re.IGNORECASE,
)
DOCUMENTATION_PIP_OPTION_WITH_ARGUMENT = (
    rb"--(?:cache-dir|cert|client-cert|exists-action|keyring-provider|log|proxy|python|retries|"
    rb"resume-retries|root-user-action|timeout|trusted-host|use-deprecated|use-feature)"
)
DOCUMENTATION_PIP_OPTION_WITHOUT_ARGUMENT = (
    rb"(?:-[vq]{1,3}|--(?:debug|disable-pip-version-check|isolated|no-cache-dir|no-color|no-input|"
    rb"no-python-version-warning|quiet|require-virtualenv|verbose))"
)
DOCUMENTATION_PIP_OPTION = (
    rb"(?:"
    + DOCUMENTATION_PIP_OPTION_WITH_ARGUMENT
    + rb"(?:="
    + DOCUMENTATION_ENV_OPTION_ARGUMENT
    + rb"|\s+"
    + DOCUMENTATION_ENV_OPTION_ARGUMENT
    + rb")|"
    + DOCUMENTATION_PIP_OPTION_WITHOUT_ARGUMENT
    + rb")"
)
DOCUMENTATION_PYTHON_OPTION_WITH_ARGUMENT = (
    rb"(?:-[WX](?:=|\s+)?|--check-hash-based-pycs(?:=|\s+))" + DOCUMENTATION_ENV_OPTION_ARGUMENT
)
DOCUMENTATION_PYTHON_OPTION_WITHOUT_ARGUMENT = rb"(?:-[BbEhiIOPqRsSuvVx]+|--(?:help|version))"
DOCUMENTATION_PYTHON_OPTION = (
    rb"(?:" + DOCUMENTATION_PYTHON_OPTION_WITH_ARGUMENT + rb"|" + DOCUMENTATION_PYTHON_OPTION_WITHOUT_ARGUMENT + rb")"
)
DOCUMENTATION_PYTHON_LAUNCHER = rb"(?:python(?:[0-9.]+)?|py(?:\s+-[0-9.]+)?)"
DOCUMENTATION_JS_OPTION_WITH_ARGUMENT = rb"--(?:cache|cafile|https-proxy|prefix|proxy|registry|userconfig)"
DOCUMENTATION_JS_OPTION = (
    rb"(?:"
    + DOCUMENTATION_JS_OPTION_WITH_ARGUMENT
    + rb"(?:="
    + DOCUMENTATION_ENV_OPTION_ARGUMENT
    + rb"|\s+"
    + DOCUMENTATION_ENV_OPTION_ARGUMENT
    + rb")|--?[A-Za-z][A-Za-z0-9_-]*(?:=[^\s]+)?)"
)
DOCUMENTATION_PIP_INSTALL_COMMAND = (
    rb"(?:"
    + DOCUMENTATION_PYTHON_LAUNCHER
    + rb"(?:\s+"
    + DOCUMENTATION_PYTHON_OPTION
    + rb"){0,8}\s+-m\s+)?pip(?:[0-9.]+)?"
    rb"(?:\s+" + DOCUMENTATION_PIP_OPTION + rb"){0,8}\s+install"
)
DOCUMENTATION_PACKAGE_INSTALL_COMMAND = (
    rb"(?:" + DOCUMENTATION_PIP_INSTALL_COMMAND + rb"|pipx\s+install"
    rb"|uv\s+(?:pip\s+install|add)"
    rb"|(?:conda|mamba|micromamba)\s+install"
    rb"|poetry\s+add"
    rb"|(?:npm|pnpm|bun)(?:\s+" + DOCUMENTATION_JS_OPTION + rb"){0,8}\s+"
    rb"(?:install|add|i|in|ins|inst|insta|instal|isnt|isnta|isntal|isntall)"
    rb"|yarn\s+add"
    rb"|cargo\s+install"
    rb"|gem\s+install"
    rb"|go\s+install"
    rb")\b"
)
DOCUMENTATION_PACKAGE_INSTALL_PATTERN = re.compile(
    DOCUMENTATION_SHELL_LINE_PREFIX + DOCUMENTATION_SHELL_WRAPPED_COMMAND + DOCUMENTATION_PACKAGE_INSTALL_COMMAND,
    re.IGNORECASE,
)
DOCUMENTATION_DIRECT_PACKAGE_INSTALL_PATTERN = re.compile(
    DOCUMENTATION_SHELL_LINE_PREFIX + DOCUMENTATION_PIP_INSTALL_COMMAND + rb"\b",
    re.IGNORECASE,
)
DOCUMENTATION_PACKAGE_VERSION_ARGUMENT_PATTERN = re.compile(
    rb"\s+[A-Za-z0-9][A-Za-z0-9._-]*(?:\[[A-Za-z0-9._,-]+\])?"
    rb"==(?P<version>[0-9]{1,3}(?:\.[0-9]{1,3}){3})\s*$"
)
DOCUMENTATION_PACKAGE_INSTALL_PROSE_TAIL_PATTERN = re.compile(
    rb"(?:\b(?:is|are|was|were)\s+(?:covered|described|documented|explained)\s+(?:at|in|on)"
    rb"|\b(?:docs?|documentation|guide|reference)\s+(?:at|in|on))\s*$",
    re.IGNORECASE,
)
DOCUMENTATION_COMPOUND_IMPORT_PREFIX_PATTERN = re.compile(
    rb"^\s*(?:(?:if|elif|else|for|while|with|try|except|finally|match|case|def|class)\b"
    rb"|async\s+(?:for|with|def)\b)[^#\n]{0,4096}:\s*$"
)
DOCUMENTATION_PYTHON_DEFINITION_BLOCK_PATTERN = re.compile(
    rb"(?:(?:async\s+)?def\s+[A-Za-z_][A-Za-z0-9_]*\s*\([^#\n]{0,2048}\)[^#\n]{0,512}"
    rb"|class\s+[A-Za-z_][A-Za-z0-9_]*(?:\s*\([^#\n]{0,2048}\))?)\s*:\s*(?:#.*)?$"
)
DOCUMENTATION_PYTHON_NESTED_BLOCK_PATTERN = re.compile(
    rb"(?:(?:async\s+)?(?:for|with)|if|elif|else|while|try|except|finally|match|case)\b"
    rb"[^#\n]{0,4096}:\s*(?:#.*)?$"
)
DOCUMENTATION_PYTHON_BLOCK_VALUE_PREFIX_PATTERN = re.compile(
    rb"(?:return|yield)(?:\s+from)?\b[\s(\[{\\]{1,4096}[rubfRUBF]*[\"']?$"
)
DOCUMENTATION_SEMICOLON_CODE_PREFIX_PATTERN = re.compile(
    rb"(?:^|;)\s*(?:"
    rb"[A-Za-z_][A-Za-z0-9_.]*\s*=[^;\n]*"
    rb"|[A-Za-z_][A-Za-z0-9_.]*\s*\([^()\n]{0,4096}\)"
    rb"|(?:from\s+[A-Za-z_][A-Za-z0-9_.]*\s+import|import\s+)[^;\n]*"
    rb"|(?:(?:if|elif|else|for|while|with|try|except|finally|match|case|def|class)\b"
    rb"|async\s+(?:for|with|def)\b)[^;\n]{0,4096}:[^;\n]*"
    rb");\s*$",
)
DOCUMENTATION_SUSPICIOUS_NETWORK_LABEL_PATTERN = re.compile(
    rb"\b(?:beacon|callback|c2|command(?:[_ -]+and[_ -]+control)?|exfil(?:tration)?|phone[_ -]+home|webhook)\b"
    rb"(?P<suffix>[^\n:]{0,32}):\s*$",
    re.IGNORECASE,
)
DOCUMENTATION_PASSIVE_NETWORK_LABEL_SUFFIX_PATTERN = re.compile(
    rb"\b(?:analysis|article|discussion|docs?|documentation|example|guide|overview|paper|reference|research)\b",
    re.IGNORECASE,
)
DOCUMENTATION_ACTIONABLE_NETWORK_LABEL_SUFFIX_PATTERN = re.compile(
    rb"\b(?:address|destination|endpoint|host|receiver|server|sink|target|uri|url)\b",
    re.IGNORECASE,
)
GENERIC_CC_BENIGN_TERM_PATTERN = rb"(?:malwares?|backdoors?|trojans?|botnets?|zombies?)"
BENIGN_DOCUMENTATION_CC_PATTERN = re.compile(
    rb"(?:"
    rb"\b(?:not|no|without)\s+(?:a\s+)?(?:known\s+)?" + GENERIC_CC_BENIGN_TERM_PATTERN + rb"\b"
    rb"|\b" + GENERIC_CC_BENIGN_TERM_PATTERN + rb"[ -]free\b"
    rb"|\b" + GENERIC_CC_BENIGN_TERM_PATTERN + rb"\s+"
    rb"(?:analysis|benchmark|classification|classifier|dataset|defen[cs]e|detection|indicators?|mitigation|research|resistance|robustness|testing)\b"
    rb"|\b(?:detect(?:ing|ion|s)?|mitigat(?:e|ing|ion)|resistan(?:ce|t)|robust(?:ness)?)\s+"
    + GENERIC_CC_BENIGN_TERM_PATTERN
    + rb"\b"
    rb")",
    re.IGNORECASE,
)
GENERIC_CC_PROSE_PATTERNS = frozenset({"backdoor", "botnet", "malware", "trojan", "zombie"})
REQUIREMENTS_URL_DIRECTIVE_PATTERN = re.compile(
    rb"^(?:(?:--index-url|--extra-index-url|--find-links)(?:\s+|=)"
    rb"|(?:-i|-f)(?:\s+|(?=[A-Za-z][A-Za-z0-9+.-]*://)))",
    re.IGNORECASE,
)
REQUIREMENTS_DIRECT_REFERENCE_PATTERN = re.compile(
    rb"^[A-Za-z0-9_.-]+(?:\[[^\]\r\n]+\])?\s*@\s*[A-Za-z][A-Za-z0-9+.-]*://",
    re.IGNORECASE,
)
TRUSTED_REQUIREMENTS_HOSTS = frozenset(
    {
        "download.pytorch.org",
        "files.pythonhosted.org",
        "pypi.org",
        "pypi.python.org",
    }
)
SENSITIVE_REQUIREMENTS_QUERY_KEYS = frozenset(
    {
        "access_token",
        "api_key",
        "auth",
        "authorization",
        "credential",
        "password",
        "secret",
        "sig",
        "signature",
        "token",
        "x_amz_credential",
        "x_amz_security_token",
        "x_amz_signature",
    }
)


class TextScanner(BaseScanner):
    """Scanner for text-based ML-related files."""

    name = "text"
    supported_extensions: ClassVar[list[str]] = [".txt", ".md", ".markdown", ".rst", ".env"]
    default_max_file_read_size = DEFAULT_TEXT_CONTENT_SECURITY_SCAN_BYTES

    def __init__(self, config: dict[str, Any] | None = None):
        """Initialize the scanner with optional configuration."""
        super().__init__(config)

    @classmethod
    def _is_readme_documentation_filename(cls, filename: str) -> bool:
        return filename == "readme" or (
            filename.startswith("readme.") and os.path.splitext(filename)[1].lower() in cls.supported_extensions
        )

    @classmethod
    def _is_model_card_documentation_filename(cls, filename: str) -> bool:
        return filename == "model_card" or (
            filename.startswith(("model_card.", "modelcard."))
            and os.path.splitext(filename)[1].lower() in cls.supported_extensions
        )

    @classmethod
    def can_handle(cls, path: str) -> bool:
        """Check if this scanner can handle the given file."""
        filename = os.path.basename(path).lower()
        if cls._is_model_card_documentation_filename(filename) or cls._is_readme_documentation_filename(filename):
            return True

        # Check for ML-related text files
        ml_text_files = {
            "readme.md",
            "readme.rst",
            "readme.txt",
            "readme.markdown",
            "vocab.txt",
            "vocabulary.txt",
            "tokens.txt",
            "tokenizer.txt",
            "merges.txt",
            "labels.txt",
            "classes.txt",
            "model_card.md",
            "model_card.rst",
            "model_card.txt",
            "modelcard.md",
            "license.txt",
            "license.md",
            "license.rst",
            "requirements.txt",
            ".env",
        }
        if filename in ml_text_files:
            return True

        ext = os.path.splitext(path)[1].lower()
        if ext not in cls.supported_extensions:
            return False
        if ext == ".env":
            return True

        return any(filename.startswith(prefix) for prefix in ["vocab", "token", "label"])

    @staticmethod
    def _get_file_size(path: str) -> int:
        """Return file size for bounded text classification."""
        return os.path.getsize(path)

    def _get_content_security_scan_bytes(self) -> int:
        return self._normalize_positive_int_config(
            self.config.get("text_content_scan_bytes", self.max_file_read_size),
            DEFAULT_TEXT_CONTENT_SECURITY_SCAN_BYTES,
        )

    def _get_content_security_max_findings(self) -> int:
        return self._normalize_positive_int_config(
            self.config.get("text_content_max_findings", DEFAULT_TEXT_CONTENT_SECURITY_MAX_FINDINGS),
            DEFAULT_TEXT_CONTENT_SECURITY_MAX_FINDINGS,
        )

    @classmethod
    def _is_documentation_sidecar(cls, path: str) -> bool:
        filename = os.path.basename(path).lower()
        return (
            filename in DOCUMENTATION_TEXT_FILENAMES
            or cls._is_readme_documentation_filename(filename)
            or cls._is_model_card_documentation_filename(filename)
        )

    @staticmethod
    def _is_passive_data_sidecar(path: str) -> bool:
        filename = os.path.basename(path).lower()
        return filename in PASSIVE_DATA_TEXT_FILENAMES or filename.startswith(PASSIVE_DATA_TEXT_PREFIXES)

    @staticmethod
    def _has_tokenizer_vocabulary_filename(path: str) -> bool:
        filename = os.path.basename(path).lower()
        return filename in TOKENIZER_VOCABULARY_FILENAMES or (
            filename.endswith(".txt") and filename.startswith(TOKENIZER_VOCABULARY_PREFIXES)
        )

    @staticmethod
    def _is_tokenizer_vocabulary_token_line(line: bytes) -> bool:
        if not line or len(line) > MAX_TOKENIZER_VOCABULARY_TOKEN_BYTES:
            return False
        if line != line.strip():
            return False
        return not any(value <= 0x20 or value == 0x7F for value in line)

    @staticmethod
    def _find_next_line_separator(payload: bytes, start: int) -> tuple[int, int]:
        payload_length = len(payload)
        index = start
        while index < payload_length:
            value = payload[index]
            if value == 0x0A:
                return index, index + 1
            if value == 0x0D:
                next_start = index + 1
                if next_start < payload_length and payload[next_start] == 0x0A:
                    next_start += 1
                return index, next_start
            index += 1
        return payload_length, payload_length

    @classmethod
    def _tokenizer_vocabulary_line_evidence(cls, payload: bytes) -> tuple[int, int, int, int]:
        token_lines = 0
        nonempty_lines = 0
        sentinel_lines = 0
        subword_lines = 0
        line_start = 0
        payload_length = len(payload)
        while line_start < payload_length:
            line_end, next_line_start = cls._find_next_line_separator(payload, line_start)
            raw_line = payload[line_start:line_end]
            line_start = next_line_start
            line = raw_line.strip()
            if not line:
                continue
            nonempty_lines += 1
            if not cls._is_tokenizer_vocabulary_token_line(line):
                continue
            token_lines += 1
            if line in TOKENIZER_VOCABULARY_SENTINELS:
                sentinel_lines += 1
            try:
                line_text = line.decode("utf-8")
            except UnicodeDecodeError:
                continue
            if line_text.startswith(TOKENIZER_VOCABULARY_SUBWORD_PREFIXES) or line_text.endswith(
                TOKENIZER_VOCABULARY_SUBWORD_SUFFIXES
            ):
                subword_lines += 1
        return nonempty_lines, token_lines, sentinel_lines, subword_lines

    @classmethod
    def _has_line_oriented_tokenizer_vocabulary_evidence(cls, path: str, payload: bytes) -> bool:
        nonempty_lines, token_lines, sentinel_lines, subword_lines = cls._tokenizer_vocabulary_line_evidence(payload)
        if nonempty_lines == 0 or token_lines / nonempty_lines < MIN_TOKENIZER_VOCABULARY_TOKEN_LINE_RATIO:
            return False

        if cls._has_tokenizer_vocabulary_filename(path):
            return nonempty_lines >= MIN_TOKENIZER_VOCABULARY_LINES

        return (
            nonempty_lines >= MIN_STRONG_TOKENIZER_VOCABULARY_LINES
            and sentinel_lines >= MIN_STRONG_TOKENIZER_VOCABULARY_SENTINELS
            and subword_lines >= MIN_STRONG_TOKENIZER_VOCABULARY_SUBWORD_LINES
        )

    @classmethod
    def _finding_line_parts(cls, payload: bytes, finding: dict[str, Any]) -> tuple[bytes, int] | None:
        position = finding.get("position")
        if not isinstance(position, int) or position < 0 or position > len(payload):
            return None
        previous_separator = max(payload.rfind(b"\n", 0, position), payload.rfind(b"\r", 0, position))
        line_start = max(previous_separator + 1, position - MAX_TEXT_FINDING_CONTEXT_BYTES)
        line_end, _ = cls._find_next_line_separator(payload, position)
        line_end = min(line_end, position + MAX_TEXT_FINDING_CONTEXT_BYTES)
        return payload[line_start:line_end], position - line_start

    @classmethod
    def _finding_line(cls, payload: bytes, finding: dict[str, Any]) -> bytes | None:
        line_parts = cls._finding_line_parts(payload, finding)
        return line_parts[0].strip() if line_parts is not None else None

    @staticmethod
    def _finding_line_prefix_is_truncated(payload: bytes, finding: dict[str, Any]) -> bool:
        position = finding.get("position")
        if not isinstance(position, int) or position < 0 or position > len(payload):
            return False
        return position - (payload.rfind(b"\n", 0, position) + 1) > MAX_TEXT_FINDING_CONTEXT_BYTES

    @staticmethod
    def _documentation_python_statements(line: bytes) -> list[ast.stmt]:
        source = line.strip()
        markdown_prefix = DOCUMENTATION_MARKDOWN_PREFIX_PATTERN.match(source)
        if markdown_prefix is not None:
            source = source[markdown_prefix.end() :].lstrip()
        for fence_length in (3, 2, 1):
            fence = b"`" * fence_length
            if len(source) > fence_length * 2 and source.startswith(fence) and source.endswith(fence):
                source = source[fence_length:-fence_length].strip()
                break
        if source.startswith((b">>>", b"...")):
            source = source[3:].lstrip()
        try:
            parsed = ast.parse(source.decode("utf-8"))
        except (SyntaxError, UnicodeDecodeError, ValueError):
            return []
        return parsed.body

    @classmethod
    def _documentation_line_has_import_statement(cls, line: bytes) -> bool:
        return any(
            isinstance(statement, (ast.Import, ast.ImportFrom))
            for statement in cls._documentation_python_statements(line)
        )

    @classmethod
    def _documentation_line_has_definition(cls, line: bytes) -> bool:
        return any(
            isinstance(statement, (ast.AsyncFunctionDef, ast.ClassDef, ast.FunctionDef))
            for statement in cls._documentation_python_statements(line)
        )

    @staticmethod
    def _documentation_without_closed_inline_code_spans(source: bytes) -> bytes:
        if b"`" not in source:
            return source

        result = bytearray()
        cursor = 0
        while cursor < len(source):
            if source[cursor : cursor + 1] != b"`":
                result.append(source[cursor])
                cursor += 1
                continue

            fence_end = cursor
            while fence_end < len(source) and source[fence_end : fence_end + 1] == b"`":
                fence_end += 1
            fence = source[cursor:fence_end]
            closing_fence = source.find(fence, fence_end)
            if closing_fence < 0:
                result.extend(source[cursor:])
                break

            if result and result[-1] not in b" \t\r\n":
                result.append(ord(" "))
            cursor = closing_fence + len(fence)
            if cursor < len(source) and source[cursor] not in b" \t\r\n|,.;:)":
                result.append(ord(" "))
        return bytes(result)

    @staticmethod
    def _documentation_prefix_is_markdown_table_row(prefix: bytes) -> bool:
        source = prefix.lstrip()
        markdown_prefix = DOCUMENTATION_MARKDOWN_PREFIX_PATTERN.match(source)
        if markdown_prefix is not None:
            source = source[markdown_prefix.end() :].lstrip()
        return source.startswith(b"|") and b"|" in source[1:]

    @staticmethod
    def _documentation_prefix_has_enclosing_call(prefix: bytes) -> bool:
        """Return whether a bounded Python prefix leaves a function call open at the finding."""
        source = prefix.strip()
        markdown_prefix = DOCUMENTATION_MARKDOWN_PREFIX_PATTERN.match(source)
        if markdown_prefix is not None:
            source = source[markdown_prefix.end() :].lstrip()
        source = TextScanner._documentation_without_closed_inline_code_spans(source).strip()
        if TextScanner._documentation_prefix_is_markdown_table_row(source):
            return False
        for fence_length in (3, 2, 1):
            fence = b"`" * fence_length
            if source.startswith(fence):
                source = source[fence_length:].lstrip()
                break
        if source.startswith((b">>>", b"...")):
            source = source[3:].lstrip()
        source = source.rstrip()
        if source.endswith((b"'", b'"')):
            source = source[:-1].rstrip()
        try:
            decoded = source.decode("utf-8")
        except UnicodeDecodeError:
            return False

        stack: list[tuple[str, bool]] = []
        previous: tokenize.TokenInfo | None = None
        before_previous: tokenize.TokenInfo | None = None
        previous_closed_subscript = False
        expression_keywords = {
            "and",
            "await",
            "elif",
            "if",
            "in",
            "is",
            "lambda",
            "not",
            "or",
            "return",
            "while",
            "yield",
        }
        ignored_token_types = {
            token.COMMENT,
            token.DEDENT,
            token.ENDMARKER,
            token.INDENT,
            token.NEWLINE,
            tokenize.ENCODING,
            tokenize.NL,
        }
        try:
            tokens = tokenize.generate_tokens(io.StringIO(decoded).readline)
            for current in tokens:
                if current.type in ignored_token_types:
                    continue
                current_closed_subscript = False
                if current.type == token.OP and current.string in "([{":
                    name_starts_call = (
                        previous is not None
                        and previous.type == token.NAME
                        and not keyword.iskeyword(previous.string)
                        and (
                            before_previous is None
                            or before_previous.type == token.OP
                            or (before_previous.type == token.NAME and before_previous.string in expression_keywords)
                        )
                    )
                    follows_callable_expression = (
                        previous is not None
                        and previous.type == token.OP
                        and (previous.string == ")" or (previous.string == "]" and previous_closed_subscript))
                    )
                    is_call = current.string == "(" and (name_starts_call or follows_callable_expression)
                    is_subscript = (
                        current.string == "["
                        and previous is not None
                        and previous.end == current.start
                        and (
                            (previous.type == token.NAME and not keyword.iskeyword(previous.string))
                            or (previous.type == token.OP and previous.string in {")", "]"})
                        )
                    )
                    stack.append((current.string, is_call or is_subscript))
                elif current.type == token.OP and current.string in ")]}":
                    expected = {")": "(", "]": "[", "}": "{"}[current.string]
                    if stack and stack[-1][0] == expected:
                        _, opens_callable_expression = stack.pop()
                        current_closed_subscript = current.string == "]" and opens_callable_expression
                before_previous = previous
                previous = current
                previous_closed_subscript = current_closed_subscript
        except (IndentationError, tokenize.TokenError):
            # Incomplete prefixes are expected; the partial stack still identifies an open call.
            return any(opening == "(" and is_call for opening, is_call in stack)
        return any(opening == "(" and is_call for opening, is_call in stack)

    @staticmethod
    def _documentation_passive_markdown_link_match(prefix: bytes) -> re.Match[bytes] | None:
        return DOCUMENTATION_MARKDOWN_LINK_URL_PREFIX_PATTERN.search(prefix.rstrip())

    @classmethod
    def _documentation_prefix_is_passive_markdown_link(cls, prefix: bytes) -> bool:
        return cls._documentation_passive_markdown_link_match(prefix) is not None

    @classmethod
    def _documentation_markdown_link_is_in_code_context(cls, prefix: bytes, link_start: int) -> bool:
        code_prefix = prefix[:link_start]
        return (
            cls._documentation_assignment_is_actionable(code_prefix)
            or DOCUMENTATION_CODE_LITERAL_VALUE_PREFIX_PATTERN.search(code_prefix) is not None
            or DOCUMENTATION_CODE_RETURN_STRING_PATTERN.search(code_prefix) is not None
            or DOCUMENTATION_CODE_CALL_PATTERN.search(code_prefix) is not None
            or cls._documentation_markdown_link_config_is_actionable(code_prefix)
        )

    @classmethod
    def _documentation_markdown_link_config_is_actionable(cls, code_prefix: bytes) -> bool:
        stripped = code_prefix.rstrip()
        return (
            cls._documentation_structured_config_value_prefix_is_actionable(code_prefix)
            or DOCUMENTATION_CONFIG_LIST_MAPPING_PATTERN.search(code_prefix) is not None
            or DOCUMENTATION_CONFIG_MARKDOWN_UNQUOTED_MAPPING_PATTERN.search(code_prefix) is not None
            or DOCUMENTATION_CONFIG_MARKDOWN_MAPPING_PATTERN.search(code_prefix) is not None
            or (
                stripped.endswith((b'"', b"'")) and DOCUMENTATION_CONFIG_MAPPING_PATTERN.search(code_prefix) is not None
            )
            or cls._documentation_nested_config_is_actionable(code_prefix)
            or DOCUMENTATION_CONFIG_TAG_PATTERN.search(code_prefix) is not None
        )

    @classmethod
    def _documentation_markdown_link_context(cls, payload: bytes, position: int) -> tuple[bytes, int] | None:
        line_start = max(payload.rfind(b"\n", 0, position) + 1, position - MAX_TEXT_FINDING_CONTEXT_BYTES)
        line_end = payload.find(b"\n", position)
        if line_end < 0:
            line_end = len(payload)
        line_end = min(line_end, position + MAX_TEXT_FINDING_CONTEXT_BYTES)
        line = payload[line_start:line_end]
        line_position = position - line_start
        for match in BARE_NETWORK_URL_TOKEN_PATTERN.finditer(line):
            if match.start() <= line_position < match.end():
                prefix = line[: match.start()]
                markdown_match = cls._documentation_passive_markdown_link_match(prefix)
                if markdown_match is None:
                    return None
                link_start = line_start + markdown_match.start()
                context_start = max(0, link_start - MAX_TEXT_FINDING_CONTEXT_BYTES)
                if context_start > 0:
                    next_newline = payload.find(b"\n", context_start, link_start)
                    if next_newline >= 0:
                        context_start = next_newline + 1
                return payload[context_start:link_start], link_start
        return None

    @classmethod
    def _documentation_markdown_link_context_prefix(cls, payload: bytes, position: int) -> bytes | None:
        context = cls._documentation_markdown_link_context(payload, position)
        return context[0] if context is not None else None

    @classmethod
    def _documentation_markdown_link_xml_config_context_status(cls, payload: bytes, link_start: int) -> bool | None:
        line_start = payload.rfind(b"\n", 0, link_start) + 1
        context_start = max(line_start, link_start - MAX_TEXT_TRUNCATED_XML_CONTEXT_BYTES)
        context_prefix = payload[context_start:link_start]
        tag_match = None
        for match in DOCUMENTATION_CONFIG_TAG_START_PATTERN.finditer(context_prefix):
            tag_match = match
            break
        if tag_match is None:
            return None if context_start > line_start else False
        return cls._documentation_config_xml_tag_value_is_open(context_prefix[tag_match.start() :])

    @classmethod
    def _documentation_markdown_link_has_open_xml_config_context(cls, payload: bytes, link_start: int) -> bool:
        return cls._documentation_markdown_link_xml_config_context_status(payload, link_start) is True

    @classmethod
    def _documentation_position_is_in_actionable_markdown_link_context(cls, payload: bytes, position: int) -> bool:
        context = cls._documentation_markdown_link_context(payload, position)
        if context is None:
            return False
        context_prefix, link_start = context
        line_prefix = context_prefix[context_prefix.rfind(b"\n") + 1 :]
        if cls._documentation_shell_comment_before_position(line_prefix, len(line_prefix)):
            return False
        if cls._documentation_markdown_link_leading_prefix_is_passive(line_prefix):
            return cls._documentation_markdown_link_config_is_actionable(
                context_prefix
            ) or cls._documentation_markdown_link_has_open_xml_config_context(
                payload,
                link_start,
            )
        return cls._documentation_markdown_link_is_in_code_context(
            context_prefix,
            len(context_prefix),
        ) or cls._documentation_markdown_link_has_open_xml_config_context(
            payload,
            link_start,
        )

    @classmethod
    def _documentation_position_is_in_passive_markdown_link(cls, payload: bytes, position: int) -> bool:
        context = cls._documentation_markdown_link_context(payload, position)
        if context is None:
            return False
        context_prefix, link_start = context
        line_prefix = context_prefix[context_prefix.rfind(b"\n") + 1 :]
        passive_line_markdown_link = cls._documentation_markdown_link_leading_prefix_is_passive(line_prefix)
        literal_value_prefix = cls._documentation_markdown_link_leading_prefix_is_literal_value(line_prefix)
        return cls._documentation_markdown_link_xml_config_context_status(payload, link_start) is False and (
            (passive_line_markdown_link and not cls._documentation_markdown_link_config_is_actionable(context_prefix))
            or (
                not literal_value_prefix
                and not cls._documentation_markdown_link_is_in_code_context(
                    context_prefix,
                    len(context_prefix),
                )
            )
        )

    @staticmethod
    def _documentation_comment_contains_position(payload: bytes, position: int) -> bool:
        """Return whether a bounded finding position is inside an HTML or C-style block comment."""
        context_start = max(0, position - MAX_TEXT_FINDING_CONTEXT_BYTES)
        if context_start > 0 and payload[context_start - 1 : context_start] not in {b"\n", b"\r"}:
            return False
        prefix = payload[context_start:position]
        comment_close: bytes | None = None
        quote: int | None = None
        escaped = False
        cursor = 0
        while cursor < len(prefix):
            if comment_close is not None:
                if prefix.startswith(comment_close, cursor):
                    cursor += len(comment_close)
                    comment_close = None
                else:
                    cursor += 1
                continue
            value = prefix[cursor]
            if escaped:
                escaped = False
                cursor += 1
                continue
            if quote is not None:
                if value == ord("\\") and quote != ord("'"):
                    escaped = True
                elif value == quote:
                    quote = None
                cursor += 1
                continue
            if value in {ord("'"), ord('"'), ord("`")}:
                quote = value
                cursor += 1
            elif prefix.startswith(b"<!--", cursor):
                comment_close = b"-->"
                cursor += 4
            elif prefix.startswith(b"/*", cursor):
                comment_close = b"*/"
                cursor += 2
            else:
                cursor += 1
        return comment_close is not None

    @staticmethod
    def _documentation_shell_comment_before_position(line: bytes, position: int) -> bool:
        quote: int | None = None
        escaped = False
        for index, value in enumerate(line[:position]):
            if escaped:
                escaped = False
                continue
            if value == ord("\\") and quote != ord("'"):
                escaped = True
                continue
            if quote is not None:
                if value == quote:
                    quote = None
                continue
            if value in {ord("'"), ord('"')}:
                quote = value
                continue
            if value == ord("#") and (index == 0 or line[index - 1] in b" \t;|&()"):
                return True
        return False

    @staticmethod
    def _documentation_quoted_value_is_open(source: bytes, quote: int, value_start: int) -> bool:
        escaped = False
        cursor = value_start
        while cursor < len(source):
            value = source[cursor]
            if escaped:
                escaped = False
                cursor += 1
                continue
            if value == ord("\\") and quote != ord("'"):
                escaped = True
                cursor += 1
                continue
            if value in {ord("\r"), ord("\n")}:
                return False
            if value == quote:
                if quote == ord("'") and cursor + 1 < len(source) and source[cursor + 1] == quote:
                    cursor += 2
                    continue
                return False
            cursor += 1
        return True

    @staticmethod
    def _documentation_xml_start_tag_end(prefix: bytes, search_start: int) -> int | None:
        quote: int | None = None
        cursor = search_start
        while cursor < len(prefix):
            value = prefix[cursor]
            if quote is not None:
                if value == quote:
                    quote = None
                cursor += 1
                continue
            if value in {ord("'"), ord('"')}:
                quote = value
            elif value == ord(">"):
                return cursor
            elif value == ord("<"):
                return None
            cursor += 1
        return None

    @classmethod
    def _documentation_config_xml_tag_value_is_open(cls, prefix: bytes) -> bool:
        open_tags: list[bytes] = []
        for match in DOCUMENTATION_CONFIG_TAG_START_PATTERN.finditer(prefix):
            tag = match.group("tag").lower()
            tag_end = cls._documentation_xml_start_tag_end(prefix, match.end())
            if tag_end is None:
                return True
            if match.group("closing"):
                if not open_tags or open_tags[-1] != tag:
                    return True
                open_tags.pop()
                continue
            tag_body = prefix[match.end() : tag_end].rstrip()
            if tag_body.endswith(b"/"):
                continue
            open_tags.append(tag)
        return bool(open_tags)

    @classmethod
    def _documentation_closed_config_xml_suffix_start(cls, prefix: bytes) -> int | None:
        open_tags: list[bytes] = []
        last_tag_end: int | None = None
        for match in DOCUMENTATION_CONFIG_TAG_START_PATTERN.finditer(prefix):
            tag = match.group("tag").lower()
            tag_end = cls._documentation_xml_start_tag_end(prefix, match.end())
            if tag_end is None:
                return None
            last_tag_end = tag_end + 1
            if match.group("closing"):
                if not open_tags or open_tags[-1] != tag:
                    return None
                open_tags.pop()
                continue
            tag_body = prefix[match.end() : tag_end].rstrip()
            if tag_body.endswith(b"/"):
                continue
            open_tags.append(tag)
        if last_tag_end is None or open_tags:
            return None
        return last_tag_end

    @classmethod
    def _documentation_truncated_prefix_after_closed_xml_config_is_passive(cls, payload: bytes, position: int) -> bool:
        line_start = payload.rfind(b"\n", 0, position) + 1
        context_start = max(line_start, position - MAX_TEXT_TRUNCATED_XML_CONTEXT_BYTES)
        context_prefix = payload[context_start:position]
        tag_match = None
        for match in DOCUMENTATION_CONFIG_TAG_START_PATTERN.finditer(context_prefix):
            tag_match = match
            break
        if tag_match is None:
            return False
        line_end = payload.find(b"\n", position)
        if line_end < 0:
            line_end = len(payload)
        line_end = min(line_end, position + MAX_TEXT_FINDING_CONTEXT_BYTES)
        tag_context = context_prefix[tag_match.start() :] + payload[position:line_end]
        tag_context_position = position - (context_start + tag_match.start())
        suffix_start = cls._documentation_closed_config_xml_suffix_start(tag_context[:tag_context_position])
        if suffix_start is None:
            return False
        suffix_line = tag_context[suffix_start:]
        suffix_position = tag_context_position - suffix_start
        return not cls._documentation_line_is_code_shaped(suffix_line, suffix_position)

    @classmethod
    def _documentation_config_quoted_value_line_is_actionable(cls, line_prefix: bytes) -> bool:
        for match in DOCUMENTATION_CONFIG_QUOTED_VALUE_OPEN_PATTERN.finditer(line_prefix):
            quote = match.group("quote")[0]
            if cls._documentation_quoted_value_is_open(line_prefix, quote, match.end()):
                return True
        return False

    @classmethod
    def _documentation_nested_config_quoted_value_is_actionable(cls, prefix: bytes) -> bool:
        for object_match in DOCUMENTATION_NESTED_CONFIG_OBJECT_QUOTED_VALUE_OPEN_PATTERN.finditer(prefix):
            quote = object_match.group("quote")[0]
            if cls._documentation_quoted_value_is_open(prefix, quote, object_match.end()):
                return True

        lines = prefix.splitlines()
        if len(lines) < 2:
            return False
        value_line = lines[-1]
        value_match = DOCUMENTATION_NESTED_CONFIG_QUOTED_VALUE_LINE_PATTERN.match(value_line)
        if value_match is None:
            return False
        quote = value_match.group("quote")[0]
        if not cls._documentation_quoted_value_is_open(value_line, quote, value_match.end()):
            return False

        value_indent = cls._documentation_line_indent(value_line)
        value_is_list_item = DOCUMENTATION_NESTED_CONFIG_LIST_ITEM_PATTERN.fullmatch(value_line) is not None
        for line_index in range(len(lines) - 2, -1, -1):
            line = lines[line_index]
            if not line.strip():
                return False
            line_indent = cls._documentation_line_indent(line)
            if line_indent > value_indent or (line_indent == value_indent and not value_is_list_item):
                continue
            if DOCUMENTATION_NESTED_CONFIG_PARENT_LINE_PATTERN.fullmatch(line) is not None:
                return True
            list_item_prefix = DOCUMENTATION_LIST_ITEM_PREFIX_PATTERN.match(line)
            if list_item_prefix is not None:
                if value_indent <= line_indent:
                    return False
                if (
                    DOCUMENTATION_NESTED_CONFIG_PARENT_LINE_PATTERN.fullmatch(line[list_item_prefix.end() :])
                    is not None
                ):
                    return True
                for parent_index in range(line_index - 1, -1, -1):
                    parent_line = lines[parent_index]
                    if not parent_line.strip():
                        return False
                    parent_indent = cls._documentation_line_indent(parent_line)
                    if parent_indent > line_indent:
                        continue
                    return DOCUMENTATION_NESTED_CONFIG_PARENT_LINE_PATTERN.fullmatch(parent_line) is not None
                return False
            return False
        return False

    @classmethod
    def _documentation_structured_config_value_prefix_is_actionable(cls, prefix: bytes) -> bool:
        line_prefix = prefix[prefix.rfind(b"\n") + 1 :]
        return (
            cls._documentation_config_quoted_value_line_is_actionable(line_prefix)
            or cls._documentation_nested_config_quoted_value_is_actionable(prefix)
            or cls._documentation_config_xml_tag_value_is_open(prefix)
        )

    @staticmethod
    def _documentation_line_indent(line: bytes) -> int:
        return len(line) - len(line.lstrip(b" \t"))

    @classmethod
    def _documentation_nested_config_is_actionable(cls, prefix: bytes) -> bool:
        if DOCUMENTATION_NESTED_CONFIG_OBJECT_PATTERN.search(prefix) is not None:
            return True
        lines = prefix.splitlines()
        if len(lines) < 2:
            return False
        value_line = lines[-1]
        if DOCUMENTATION_NESTED_CONFIG_VALUE_LINE_PATTERN.fullmatch(value_line) is None:
            return False
        value_indent = cls._documentation_line_indent(value_line)
        value_is_list_item = DOCUMENTATION_NESTED_CONFIG_LIST_ITEM_PATTERN.fullmatch(value_line) is not None
        for line_index in range(len(lines) - 2, -1, -1):
            line = lines[line_index]
            if not line.strip():
                return False
            line_indent = cls._documentation_line_indent(line)
            if line_indent > value_indent or (line_indent == value_indent and not value_is_list_item):
                continue
            if DOCUMENTATION_NESTED_CONFIG_PARENT_LINE_PATTERN.fullmatch(line) is not None:
                return True
            list_item_prefix = DOCUMENTATION_LIST_ITEM_PREFIX_PATTERN.match(line)
            if list_item_prefix is not None:
                if value_indent <= line_indent:
                    return False
                if (
                    DOCUMENTATION_NESTED_CONFIG_PARENT_LINE_PATTERN.fullmatch(line[list_item_prefix.end() :])
                    is not None
                ):
                    return True
                for parent_index in range(line_index - 1, -1, -1):
                    parent_line = lines[parent_index]
                    if not parent_line.strip():
                        return False
                    parent_indent = cls._documentation_line_indent(parent_line)
                    if parent_indent > line_indent:
                        continue
                    return DOCUMENTATION_NESTED_CONFIG_PARENT_LINE_PATTERN.fullmatch(parent_line) is not None
                return False
            return False
        return False

    @staticmethod
    def _documentation_assignment_is_actionable(prefix: bytes) -> bool:
        return (
            DOCUMENTATION_CODE_ASSIGNMENT_PATTERN.search(prefix) is not None
            and DOCUMENTATION_PASSIVE_HTML_URL_ATTRIBUTE_PATTERN.search(prefix) is None
        )

    @staticmethod
    def _documentation_suspicious_label_is_actionable(prefix: bytes) -> bool:
        for match in DOCUMENTATION_SUSPICIOUS_NETWORK_LABEL_PATTERN.finditer(prefix):
            suffix = match.group("suffix")
            if DOCUMENTATION_ACTIONABLE_NETWORK_LABEL_SUFFIX_PATTERN.search(suffix) is not None:
                return True
            if DOCUMENTATION_PASSIVE_NETWORK_LABEL_SUFFIX_PATTERN.search(suffix) is None:
                return True
        return False

    @staticmethod
    def _documentation_package_install_is_actionable(line: bytes, position: int) -> bool:
        stripped = line.lstrip()
        leading_bytes = len(line) - len(stripped)
        match = DOCUMENTATION_PACKAGE_INSTALL_PATTERN.match(stripped)
        if match is None:
            return False
        for url_match in BARE_NETWORK_URL_TOKEN_PATTERN.finditer(line):
            if url_match.start() <= position < url_match.end():
                position = url_match.start()
                break
        relative_position = max(0, position - leading_bytes)
        if relative_position < match.end():
            return True
        return (
            DOCUMENTATION_PACKAGE_INSTALL_PROSE_TAIL_PATTERN.search(stripped[match.end() : relative_position]) is None
        )

    @classmethod
    def _documentation_package_version_is_informational(
        cls,
        payload: bytes,
        finding: dict[str, Any],
    ) -> bool:
        if finding.get("type") != "ipv4_address":
            return False
        position = finding.get("position")
        ip = finding.get("ip")
        if not isinstance(position, int) or position < 0 or position > len(payload) or not isinstance(ip, str):
            return False
        ip_bytes = ip.encode()
        line_start_limit = max(0, position - MAX_TEXT_FINDING_CONTEXT_BYTES)
        previous_separator = max(
            payload.rfind(b"\n", line_start_limit, position),
            payload.rfind(b"\r", line_start_limit, position),
        )
        if previous_separator < 0 and line_start_limit > 0:
            return False
        line_start = previous_separator + 1
        line_end_limit = min(len(payload), position + len(ip_bytes) + MAX_TEXT_FINDING_CONTEXT_BYTES)
        next_separators = (
            separator
            for separator in (
                payload.find(b"\n", position, line_end_limit),
                payload.find(b"\r", position, line_end_limit),
            )
            if separator >= 0
        )
        line_end = min(next_separators, default=line_end_limit)
        if line_end == line_end_limit and line_end_limit < len(payload):
            return False
        line = payload[line_start:line_end]
        line_position = position - line_start
        stripped = line.lstrip()
        leading_bytes = len(line) - len(stripped)
        install_match = DOCUMENTATION_DIRECT_PACKAGE_INSTALL_PATTERN.match(stripped)
        if install_match is None:
            return False
        argument_match = DOCUMENTATION_PACKAGE_VERSION_ARGUMENT_PATTERN.fullmatch(stripped[install_match.end() :])
        if argument_match is None:
            return False
        version_position = leading_bytes + install_match.end() + argument_match.start("version")
        return line_position == version_position and argument_match.group("version") == ip_bytes

    @staticmethod
    def _documentation_f_string_expression_contains_position(token_text: str, local_position: int) -> bool:
        prefix_match = re.match(r"(?i)(?:[rubf]*)('''|\"\"\"|'|\")", token_text)
        if prefix_match is None or "f" not in token_text[: prefix_match.start(1)].casefold():
            return False

        quote = prefix_match.group(1)
        content_start = prefix_match.end(1)
        content_end = len(token_text) - len(quote) if token_text.endswith(quote) else len(token_text)
        if local_position < content_start or local_position >= content_end:
            return False

        cursor = content_start
        while cursor < content_end:
            current = token_text[cursor]
            if current == "{" and token_text[cursor + 1 : cursor + 2] != "{":
                expression_start = cursor + 1
                cursor += 1
                depth = 1
                quote_char: str | None = None
                triple_quote = False
                escaped = False
                while cursor < content_end:
                    expression_char = token_text[cursor]
                    if escaped:
                        escaped = False
                    elif quote_char is not None:
                        if expression_char == "\\":
                            escaped = True
                        elif triple_quote and token_text.startswith(quote_char * 3, cursor):
                            cursor += 2
                            quote_char = None
                            triple_quote = False
                        elif not triple_quote and expression_char == quote_char:
                            quote_char = None
                    elif expression_char in {"'", '"'}:
                        quote_char = expression_char
                        triple_quote = token_text.startswith(expression_char * 3, cursor)
                        if triple_quote:
                            cursor += 2
                    elif expression_char == "{":
                        depth += 1
                    elif expression_char == "}":
                        depth -= 1
                        if depth == 0:
                            if expression_start <= local_position < cursor:
                                return True
                            break
                    cursor += 1
            elif current == "{" and token_text[cursor + 1 : cursor + 2] == "{":
                cursor += 1
            cursor += 1
        return False

    @staticmethod
    def _documentation_python_string_contains_position(line: bytes, position: int) -> bool:
        text = line.decode("utf-8", errors="replace")
        character_position = len(line[:position].decode("utf-8", errors="replace"))
        try:
            for current in tokenize.generate_tokens(io.StringIO(text).readline):
                if (
                    current.start[0] == 1
                    and current.end[0] == 1
                    and current.start[1] <= character_position < current.end[1]
                ):
                    if current.type == FSTRING_MIDDLE_TOKEN_TYPE:
                        return True
                    if current.type != token.STRING:
                        continue
                    local_position = character_position - current.start[1]
                    return not TextScanner._documentation_f_string_expression_contains_position(
                        current.string,
                        local_position,
                    )
        except (IndentationError, tokenize.TokenError):
            return False
        return False

    @staticmethod
    def _line_network_token_contains_position(line: bytes, start: int, end: int, position: int) -> bool:
        bounded_line = line[start:end]
        for pattern in BARE_NETWORK_TOKEN_PATTERNS:
            for match in pattern.finditer(bounded_line):
                token_start = start + match.start()
                token_end = start + match.end()
                if token_start <= position < token_end:
                    return True
        return False

    @classmethod
    def _documentation_xargs_downloader_is_actionable(cls, line: bytes, position: int) -> bool:
        for match in DOCUMENTATION_XARGS_DOWNLOADER_PATTERN.finditer(line):
            if position < match.start():
                if cls._line_network_token_contains_position(line, 0, match.start(), position):
                    return True
                continue

            cursor = match.end()
            while cursor < len(line) and line[cursor : cursor + 1] in {b" ", b"\t"}:
                cursor += 1
            if cursor >= len(line) or line[cursor : cursor + 1] in {b"`", b"'", b'"', b".", b",", b";", b"#"}:
                continue
            if cls._line_network_token_contains_position(line, cursor, len(line), position):
                return True
        return False

    @staticmethod
    def _documentation_anchored_network_command_is_actionable(line: bytes) -> bool:
        return any(
            pattern.match(line) is not None
            for pattern in (
                DOCUMENTATION_SHELL_COMMAND_PATTERN,
                DOCUMENTATION_COMMAND_ARRAY_PATTERN,
                DOCUMENTATION_SHELL_COMMAND_ARRAY_PATTERN,
                DOCUMENTATION_FIND_EXEC_DOWNLOADER_PATTERN,
                DOCUMENTATION_DOCKER_ADD_PATTERN,
                DOCUMENTATION_CERTUTIL_COMMAND_PATTERN,
                DOCUMENTATION_NETCAT_COMMAND_PATTERN,
                DOCUMENTATION_GIT_CLONE_COMMAND_PATTERN,
                DOCUMENTATION_SSH_COMMAND_PATTERN,
                DOCUMENTATION_DOCKER_PULL_COMMAND_PATTERN,
                DOCUMENTATION_POWERSHELL_COMMAND_PATTERN,
            )
        )

    @classmethod
    def _documentation_root_prompt_command_is_actionable(cls, line: bytes) -> bool:
        stripped = line.lstrip()
        if not stripped.startswith(b"#") or not cls._documentation_anchored_network_command_is_actionable(stripped):
            return False
        root_prompt_command = stripped[1:].lstrip()
        return DOCUMENTATION_ROOT_PROMPT_NON_SHELL_PREFIX_PATTERN.match(root_prompt_command) is None

    @classmethod
    def _documentation_line_is_code_shaped(cls, line: bytes, position: int) -> bool:
        prefix = line[:position]
        stripped = line.lstrip()
        passive_markdown_link_match = cls._documentation_passive_markdown_link_match(prefix)
        passive_markdown_link = passive_markdown_link_match is not None
        markdown_table_context = cls._documentation_prefix_is_markdown_table_row(prefix)
        markdown_link_code_context = (
            cls._documentation_markdown_link_is_in_code_context(prefix, passive_markdown_link_match.start())
            if passive_markdown_link_match is not None
            else False
        )
        shell_command_is_actionable = (
            cls._documentation_anchored_network_command_is_actionable(stripped)
            or cls._documentation_package_install_is_actionable(line, position)
            or DOCUMENTATION_INLINE_NETCAT_COMMAND_PATTERN.search(line) is not None
            or DOCUMENTATION_INLINE_POWERSHELL_COMMAND_PATTERN.search(line) is not None
            or DOCUMENTATION_INLINE_SHELL_COMMAND_PATTERN.search(prefix) is not None
            or DOCUMENTATION_SHELL_SUBSTITUTION_PATTERN.search(prefix) is not None
            or cls._documentation_xargs_downloader_is_actionable(line, position)
        )
        if cls._documentation_shell_comment_before_position(
            line, position
        ) and not cls._documentation_root_prompt_command_is_actionable(stripped):
            return False
        if (
            shell_command_is_actionable
            or DOCUMENTATION_EXECUTABLE_HTML_URL_ATTRIBUTE_PATTERN.search(prefix) is not None
            or cls._documentation_suspicious_label_is_actionable(prefix)
            or (
                DOCUMENTATION_HTML_URL_ATTRIBUTE_PATTERN.search(prefix) is None
                and cls._documentation_assignment_is_actionable(prefix)
            )
            or markdown_link_code_context
            or (
                not markdown_table_context
                and not passive_markdown_link
                and DOCUMENTATION_CODE_CALL_PATTERN.search(prefix) is not None
            )
            or (
                not markdown_table_context
                and not passive_markdown_link
                and cls._documentation_prefix_has_enclosing_call(prefix)
            )
            or DOCUMENTATION_CONFIG_MAPPING_PATTERN.search(prefix) is not None
            or cls._documentation_nested_config_is_actionable(prefix)
            or DOCUMENTATION_CONFIG_TAG_PATTERN.search(prefix) is not None
            or cls._documentation_structured_config_value_prefix_is_actionable(prefix)
        ):
            return True

        statements = cls._documentation_python_statements(line)
        return any(
            isinstance(node, (ast.AnnAssign, ast.Assign, ast.AugAssign, ast.Call, ast.Lambda, ast.NamedExpr))
            for statement in statements
            for node in ast.walk(statement)
        ) or any(
            isinstance(statement, (ast.AsyncFunctionDef, ast.ClassDef, ast.FunctionDef, ast.Import, ast.ImportFrom))
            for statement in statements
        )

    @classmethod
    def _documentation_previous_line_continues_command(cls, payload: bytes, position: int) -> bool:
        line_start = payload.rfind(b"\n", 0, position) + 1
        if line_start <= 0:
            return False
        current_line_prefix = payload[line_start:position]
        if cls._documentation_shell_comment_before_position(current_line_prefix, len(current_line_prefix)):
            return False

        context_start = max(0, line_start - MAX_TEXT_FINDING_CONTEXT_BYTES)
        previous_line_end = line_start - 1
        while previous_line_end >= context_start:
            previous_line_start = max(
                payload.rfind(b"\n", context_start, previous_line_end) + 1,
                context_start,
            )
            previous_line = payload[previous_line_start:previous_line_end].rstrip()
            if not previous_line.endswith(b"\\"):
                return False
            stripped = previous_line.lstrip()
            if cls._documentation_shell_comment_before_position(previous_line, len(previous_line)) and not (
                cls._documentation_root_prompt_command_is_actionable(stripped)
            ):
                return False

            if (
                DOCUMENTATION_SHELL_COMMAND_PATTERN.match(stripped) is not None
                or DOCUMENTATION_PACKAGE_INSTALL_PATTERN.match(stripped) is not None
                or DOCUMENTATION_DOCKER_ADD_CONTINUATION_PATTERN.match(stripped) is not None
            ):
                return True
            if previous_line_start == context_start:
                return context_start > 0
            previous_line_end = previous_line_start - 1
        return False

    @staticmethod
    def _documentation_python_definition_contains_finding(payload: bytes, position: int) -> bool:
        line_start = payload.rfind(b"\n", 0, position) + 1
        current_line_prefix = payload[line_start:position]
        current_indent = len(current_line_prefix) - len(current_line_prefix.lstrip(b" \t"))
        if (
            current_indent == 0
            or DOCUMENTATION_PYTHON_BLOCK_VALUE_PREFIX_PATTERN.fullmatch(current_line_prefix.lstrip()) is None
        ):
            return False

        context_start = max(0, line_start - MAX_TEXT_FINDING_CONTEXT_BYTES)
        previous_line_end = line_start - 1
        target_indent = current_indent
        while previous_line_end >= context_start:
            previous_line_start = max(
                payload.rfind(b"\n", context_start, previous_line_end) + 1,
                context_start,
            )
            previous_line = payload[previous_line_start:previous_line_end]
            stripped = previous_line.strip()
            if stripped and not stripped.startswith(b"#"):
                indent = len(previous_line) - len(previous_line.lstrip(b" \t"))
                if indent < target_indent:
                    if DOCUMENTATION_PYTHON_DEFINITION_BLOCK_PATTERN.fullmatch(stripped) is not None:
                        return True
                    if DOCUMENTATION_PYTHON_NESTED_BLOCK_PATTERN.fullmatch(stripped) is None:
                        return False
                    target_indent = indent
            if previous_line_start == context_start:
                break
            previous_line_end = previous_line_start - 1
        return False

    @staticmethod
    def _documentation_multiline_return_contains_position(payload: bytes, position: int) -> bool:
        line_start = payload.rfind(b"\n", 0, position) + 1
        current_line_prefix = payload[line_start:position]
        current_indent = len(current_line_prefix) - len(current_line_prefix.lstrip(b" \t"))
        if current_indent == 0:
            return False

        context_start = max(0, line_start - MAX_TEXT_FINDING_CONTEXT_BYTES)
        previous_line_end = line_start - 1
        while previous_line_end >= context_start:
            previous_line_start = max(
                payload.rfind(b"\n", context_start, previous_line_end) + 1,
                context_start,
            )
            previous_line = payload[previous_line_start:previous_line_end]
            stripped = previous_line.strip()
            if stripped and not stripped.startswith(b"#"):
                previous_indent = len(previous_line) - len(previous_line.lstrip(b" \t"))
                if previous_indent < current_indent:
                    return DOCUMENTATION_PYTHON_BLOCK_VALUE_PREFIX_PATTERN.fullmatch(stripped) is not None
            if previous_line_start == context_start:
                break
            previous_line_end = previous_line_start - 1
        return False

    @staticmethod
    def _documentation_markdown_link_leading_prefix_is_passive(prefix: bytes) -> bool:
        prefix = prefix.lstrip()
        return (
            not prefix or prefix.startswith(b"#") or DOCUMENTATION_MARKDOWN_PREFIX_PATTERN.fullmatch(prefix) is not None
        )

    @staticmethod
    def _documentation_markdown_link_leading_prefix_is_literal_value(prefix: bytes) -> bool:
        stripped = prefix.strip()
        return stripped.startswith((b'"', b"'", b"{", b"[", b"(")) or stripped.endswith((b",", b"{", b"["))

    @classmethod
    def _documentation_literal_continuation_line_is_passive_markdown_prefix(cls, line: bytes) -> bool:
        markdown_match = cls._documentation_passive_markdown_link_match(line)
        if markdown_match is None:
            return False
        return cls._documentation_markdown_link_leading_prefix_is_passive(line[: markdown_match.start()])

    @classmethod
    def _documentation_literal_continuation_line_is_code_shaped(cls, line: bytes) -> bool:
        stripped = line.strip()
        if cls._documentation_literal_continuation_line_is_passive_markdown_prefix(line):
            return False
        return (
            stripped.startswith((b'"', b"'", b"{", b"[", b"(", b"-", b"+"))
            or stripped.endswith((b",", b"{", b"[", b"("))
            or bool(re.match(rb"\d", stripped))
        )

    @classmethod
    def _documentation_zero_indent_multiline_literal_contains_position(
        cls,
        payload: bytes,
        line_start: int,
        current_line_prefix: bytes,
        context_start: int,
    ) -> bool:
        if not cls._documentation_literal_continuation_line_is_code_shaped(current_line_prefix):
            return False

        previous_line_end = line_start - 1
        while previous_line_end >= context_start:
            previous_line_start = max(
                payload.rfind(b"\n", context_start, previous_line_end) + 1,
                context_start,
            )
            previous_line = payload[previous_line_start:previous_line_end].removesuffix(b"\r")
            stripped = previous_line.strip()
            if stripped and not stripped.startswith(b"#"):
                if DOCUMENTATION_CODE_LITERAL_BLOCK_PREFIX_PATTERN.search(previous_line) is not None:
                    return True
                if stripped.startswith((b"}", b"]", b")")):
                    return False
                if not cls._documentation_literal_continuation_line_is_code_shaped(previous_line):
                    return False
            if previous_line_start == context_start:
                break
            previous_line_end = previous_line_start - 1
        return False

    @classmethod
    def _documentation_open_call_contains_position(cls, payload: bytes, position: int) -> bool:
        line_start = payload.rfind(b"\n", 0, position) + 1
        current_line_prefix = payload[line_start:position]
        if cls._documentation_prefix_is_markdown_table_row(current_line_prefix):
            return False
        if cls._documentation_shell_comment_before_position(current_line_prefix, len(current_line_prefix)):
            return False
        current_indent = len(current_line_prefix) - len(current_line_prefix.lstrip(b" \t"))

        context_start = max(0, line_start - MAX_TEXT_FINDING_CONTEXT_BYTES)
        previous_line_end = line_start - 1
        while previous_line_end >= context_start:
            previous_line_start = max(
                payload.rfind(b"\n", context_start, previous_line_end) + 1,
                context_start,
            )
            previous_line = payload[previous_line_start:previous_line_end]
            stripped = previous_line.strip()
            if stripped and not stripped.startswith(b"#"):
                previous_indent = len(previous_line) - len(previous_line.lstrip(b" \t"))
                if current_indent == 0 and previous_indent == 0:
                    if cls._documentation_prefix_has_enclosing_call(payload[previous_line_start:line_start]):
                        return True
                    previous_line_end = previous_line_start - 1
                    continue
                if previous_indent < current_indent:
                    return cls._documentation_prefix_has_enclosing_call(previous_line)
            if previous_line_start == context_start:
                break
            previous_line_end = previous_line_start - 1
        return False

    @classmethod
    def _documentation_multiline_literal_contains_position(cls, payload: bytes, position: int) -> bool:
        line_start = payload.rfind(b"\n", 0, position) + 1
        current_line_prefix = payload[line_start:position]
        current_indent = len(current_line_prefix) - len(current_line_prefix.lstrip(b" \t"))

        context_start = max(0, line_start - MAX_TEXT_FINDING_CONTEXT_BYTES)
        if current_indent == 0:
            if cls._documentation_position_is_in_passive_markdown_link(payload, position):
                return False
            return cls._documentation_zero_indent_multiline_literal_contains_position(
                payload,
                line_start,
                current_line_prefix,
                context_start,
            )

        previous_line_end = line_start - 1
        while previous_line_end >= context_start:
            previous_line_start = max(
                payload.rfind(b"\n", context_start, previous_line_end) + 1,
                context_start,
            )
            previous_line = payload[previous_line_start:previous_line_end].removesuffix(b"\r")
            stripped = previous_line.strip()
            if stripped and not stripped.startswith(b"#"):
                previous_indent = len(previous_line) - len(previous_line.lstrip(b" \t"))
                if previous_indent < current_indent:
                    return DOCUMENTATION_CODE_LITERAL_BLOCK_PREFIX_PATTERN.search(previous_line) is not None
            if previous_line_start == context_start:
                break
            previous_line_end = previous_line_start - 1
        return False

    @classmethod
    def _documentation_nested_config_contains_position(cls, payload: bytes, position: int) -> bool:
        line_start = payload.rfind(b"\n", 0, position) + 1
        context_start = max(0, line_start - MAX_TEXT_FINDING_CONTEXT_BYTES)
        if context_start > 0:
            context_start = payload.rfind(b"\n", 0, context_start) + 1
        return cls._documentation_nested_config_is_actionable(payload[context_start:position])

    @classmethod
    def _documentation_finding_is_actionable(cls, payload: bytes, finding: dict[str, Any]) -> bool:
        position = finding.get("position")
        if not isinstance(position, int) or position < 0 or position > len(payload):
            return False
        if cls._documentation_comment_contains_position(payload, position):
            return False
        if cls._documentation_position_is_in_passive_bibliography_field(payload, position):
            return False
        if cls._documentation_multiline_return_contains_position(payload, position):
            return True
        if cls._documentation_open_call_contains_position(payload, position):
            return True
        if cls._documentation_multiline_literal_contains_position(payload, position):
            return True
        if cls._documentation_position_is_in_actionable_markdown_link_context(payload, position):
            return True
        if cls._documentation_position_is_in_passive_markdown_link(payload, position):
            return False
        if cls._finding_line_prefix_is_truncated(payload, finding):
            return not cls._documentation_truncated_prefix_after_closed_xml_config_is_passive(payload, position)
        line_parts = cls._finding_line_parts(payload, finding)
        markdown_table_context = False
        if line_parts is not None:
            line, line_position = line_parts
            markdown_table_context = cls._documentation_prefix_is_markdown_table_row(line[:line_position])
            if cls._documentation_line_is_code_shaped(line, line_position):
                return True
            if cls._documentation_shell_comment_before_position(line, line_position):
                return False
        if cls._documentation_previous_line_continues_command(payload, position):
            return True
        if cls._documentation_python_definition_contains_finding(payload, position):
            return True
        prefix = payload[max(0, position - MAX_TEXT_FINDING_CONTEXT_BYTES) : position]
        passive_markdown_link = cls._documentation_prefix_is_passive_markdown_link(prefix)
        return (
            cls._documentation_assignment_is_actionable(prefix)
            or (
                not markdown_table_context
                and not passive_markdown_link
                and DOCUMENTATION_CODE_CALL_PATTERN.search(prefix) is not None
            )
            or (
                not markdown_table_context
                and not passive_markdown_link
                and cls._documentation_prefix_has_enclosing_call(prefix)
            )
            or DOCUMENTATION_CONFIG_MAPPING_PATTERN.search(prefix) is not None
            or cls._documentation_nested_config_is_actionable(prefix)
            or DOCUMENTATION_CONFIG_TAG_PATTERN.search(prefix) is not None
            or cls._documentation_structured_config_value_prefix_is_actionable(prefix)
        )

    @staticmethod
    def _documentation_finding_tokens(finding: dict[str, Any]) -> tuple[bytes, ...]:
        finding_type = finding.get("type")
        if finding_type == "network_function":
            function = finding.get("function")
            return (function.encode().lower(),) if isinstance(function, str) and function else ()
        if finding_type == "cc_pattern":
            pattern = finding.get("pattern")
            return (pattern.encode().lower(),) if isinstance(pattern, str) and pattern else ()
        if finding_type == "suspicious_port":
            port = finding.get("port")
            if not isinstance(port, int):
                return ()
            port_bytes = str(port).encode()
            return (b":" + port_bytes, b"port=" + port_bytes, b"port " + port_bytes)
        if finding_type != "network_library":
            return ()

        library = finding.get("library")
        pattern = finding.get("pattern")
        if not isinstance(library, str) or not library:
            return (pattern.encode().lower(),) if isinstance(pattern, str) and pattern else ()
        tokens = (
            pattern,
            f"import {library}",
            f"from {library}",
            f"{library}.connect",
            f"{library}.request",
            f"{library}.__init__",
        )
        return tuple(token.encode().lower() for token in dict.fromkeys(tokens) if isinstance(token, str) and token)

    @staticmethod
    def _find_documentation_token(payload: bytes, token_bytes: bytes, start: int) -> int:
        return payload.find(token_bytes, start)

    @classmethod
    def _retarget_documentation_finding(
        cls,
        payload: bytes,
        lowered_payload: bytes,
        finding: dict[str, Any],
        remaining_occurrences: int,
        allow_exhaustion_probe: bool,
    ) -> tuple[dict[str, Any], bool, int]:
        finding_type = finding.get("type")
        token_bytes_options = cls._documentation_finding_tokens(finding)
        if not token_bytes_options:
            return finding, False, remaining_occurrences

        original_position = finding.get("position")
        search_start = (
            0
            if finding_type == "network_library"
            else original_position
            if isinstance(original_position, int) and original_position >= 0
            else 0
        )
        next_positions = {
            token_bytes: cls._find_documentation_token(lowered_payload, token_bytes, search_start)
            for token_bytes in token_bytes_options
        }
        while True:
            if remaining_occurrences <= 0:
                return {**finding, "position": None, "severity": "INFO"}, True, 0
            matches = (
                (position, token_bytes) for token_bytes, position in next_positions.items() if position >= search_start
            )
            next_match = min(matches, default=None, key=lambda match: match[0])
            if next_match is None:
                return finding, False, remaining_occurrences
            match_position, token_bytes = next_match
            remaining_occurrences -= 1
            position = match_position
            if finding_type == "suspicious_port":
                position += len(token_bytes) - len(str(finding["port"]).encode())
            candidate = {**finding, "position": position}
            if finding_type == "network_library":
                candidate["pattern"] = token_bytes.decode()
            if cls._documentation_comment_contains_position(payload, position):
                actionable = False
            elif finding_type == "network_function":
                actionable = not cls._documentation_network_function_is_prose(payload, candidate)
            elif finding_type == "network_library":
                actionable = not cls._documentation_network_library_is_prose(payload, candidate)
            elif finding_type == "suspicious_port":
                actionable = cls._documentation_finding_is_actionable(payload, candidate)
            else:
                actionable = not cls._documentation_cc_finding_is_benign_prose(payload, candidate)
            if actionable:
                candidate.pop("snippet", None)
                return candidate, False, remaining_occurrences
            search_start = match_position + len(token_bytes)
            for option, next_position in next_positions.items():
                if 0 <= next_position < search_start:
                    next_positions[option] = cls._find_documentation_token(lowered_payload, option, search_start)
            if remaining_occurrences <= 0:
                if allow_exhaustion_probe and not any(position >= search_start for position in next_positions.values()):
                    return candidate, False, 0
                return {**finding, "position": None, "severity": "INFO"}, True, 0

    @classmethod
    def _documentation_network_function_is_prose(cls, payload: bytes, finding: dict[str, Any]) -> bool:
        line_parts = cls._finding_line_parts(payload, finding)
        function = finding.get("function")
        if (
            line_parts is None
            or not isinstance(function, str)
            or cls._finding_line_prefix_is_truncated(payload, finding)
        ):
            return False
        line, position = line_parts
        if cls._documentation_shell_comment_before_position(line, position):
            return True
        if cls._documentation_python_string_contains_position(line, position):
            return True
        cursor = position + len(function.encode())
        while cursor < len(line) and line[cursor : cursor + 1] in {b" ", b"\t"}:
            cursor += 1
        has_call_syntax = line[cursor : cursor + 1] == b"("
        if not has_call_syntax and line[cursor : cursor + 1] == b"\\" and not line[cursor + 1 :].strip():
            finding_position = finding.get("position")
            if isinstance(finding_position, int):
                line_end = payload.find(b"\n", finding_position)
                if line_end >= 0:
                    next_line_end = payload.find(b"\n", line_end + 1)
                    if next_line_end < 0:
                        next_line_end = len(payload)
                    next_line = payload[
                        line_end + 1 : min(next_line_end, line_end + 1 + MAX_TEXT_FINDING_CONTEXT_BYTES)
                    ]
                    has_call_syntax = next_line.lstrip().startswith(b"(")
        return (
            not has_call_syntax
            and not cls._documentation_line_is_code_shaped(
                line,
                position,
            )
            and not cls._documentation_prefix_has_enclosing_call(line[:position])
        )

    @classmethod
    def _documentation_network_library_is_prose(cls, payload: bytes, finding: dict[str, Any]) -> bool:
        line_parts = cls._finding_line_parts(payload, finding)
        pattern = finding.get("pattern")
        if (
            line_parts is None
            or not isinstance(pattern, str)
            or cls._finding_line_prefix_is_truncated(payload, finding)
        ):
            return False
        line, position = line_parts
        if cls._documentation_shell_comment_before_position(line, position):
            return True
        if cls._documentation_python_string_contains_position(line, position):
            return True
        pattern_bytes = pattern.encode()
        cursor = position + len(pattern_bytes)
        while cursor < len(line) and line[cursor : cursor + 1] in {b" ", b"\t"}:
            cursor += 1
        if not pattern.casefold().startswith(("import ", "from ")) and line[cursor : cursor + 1] == b"(":
            return False

        prefix = line[:position]
        import_is_executable = (
            cls._documentation_line_has_import_statement(line)
            or DOCUMENTATION_SEMICOLON_CODE_PREFIX_PATTERN.search(prefix) is not None
            or DOCUMENTATION_COMPOUND_IMPORT_PREFIX_PATTERN.fullmatch(prefix) is not None
        )
        return (
            not import_is_executable
            and not cls._documentation_line_is_code_shaped(line, position)
            and not cls._documentation_prefix_has_enclosing_call(prefix)
        )

    @classmethod
    def _documentation_cc_finding_is_benign_prose(cls, payload: bytes, finding: dict[str, Any]) -> bool:
        pattern = finding.get("pattern")
        line_parts = cls._finding_line_parts(payload, finding)
        if (
            pattern not in GENERIC_CC_PROSE_PATTERNS
            or line_parts is None
            or cls._finding_line_prefix_is_truncated(payload, finding)
        ):
            return False
        line, position = line_parts
        if cls._documentation_shell_comment_before_position(line, position):
            return True
        return not cls._documentation_line_is_code_shaped(line, position) and any(
            match.start() <= position < match.end() for match in BENIGN_DOCUMENTATION_CC_PATTERN.finditer(line)
        )

    @classmethod
    def _standard_requirements_network_finding(cls, path: str, payload: bytes, finding: dict[str, Any]) -> bool:
        if os.path.basename(path).lower() != "requirements.txt":
            return False
        line = cls._finding_line(payload, finding)
        if line is None:
            return False
        stripped = line.strip()
        line_parts = cls._finding_line_parts(payload, finding)
        if line_parts is None:
            return False
        finding_line, position = line_parts
        raw_url_match = next(
            (
                match
                for match in REQUIREMENTS_RAW_URL_PATTERN.finditer(finding_line)
                if match.start() <= position < match.end()
            ),
            None,
        )
        if raw_url_match is None:
            return False
        try:
            raw_url = urlsplit(raw_url_match.group().decode("utf-8", errors="ignore"))
            if raw_url.username is not None or raw_url.password is not None:
                return False
            if any(
                key.casefold().replace("-", "_") in SENSITIVE_REQUIREMENTS_QUERY_KEYS
                for key, _value in parse_qsl(raw_url.query, keep_blank_values=True)
            ):
                return False
            if stripped.startswith(b"#"):
                return True
            raw_port = raw_url.port
        except ValueError:
            return False
        if raw_url.hostname is None or raw_url.hostname.casefold() not in TRUSTED_REQUIREMENTS_HOSTS:
            return False
        if raw_url.scheme.casefold() != "https" or raw_port not in {None, 443}:
            return False
        return (
            REQUIREMENTS_URL_DIRECTIVE_PATTERN.match(stripped) is not None
            or REQUIREMENTS_DIRECT_REFERENCE_PATTERN.match(stripped) is not None
            or BARE_NETWORK_URL_TOKEN_PATTERN.fullmatch(stripped) is not None
        )

    @classmethod
    def _is_bare_data_network_token(cls, payload: bytes, finding: dict[str, Any]) -> bool:
        line = cls._finding_line(payload, finding)
        if not line or b"@" in line:
            return False
        finding_type = finding.get("type")
        if finding_type in PASSIVE_NETWORK_FINDING_TYPES:
            if BARE_NETWORK_URL_TOKEN_PATTERN.fullmatch(line):
                return True
            line_text = line.decode("utf-8", errors="ignore").casefold()
            return any(
                isinstance(value, str) and line_text == value.casefold()
                for value in (finding.get("domain"), finding.get("ip"))
            )

        line_text = line.decode("utf-8", errors="ignore").casefold()
        candidates: tuple[Any, ...]
        if finding_type == "cc_pattern":
            candidates = (finding.get("pattern"),)
        elif finding_type == "network_function":
            candidates = (finding.get("function"),)
        elif finding_type == "network_library":
            candidates = (finding.get("pattern"), finding.get("library"))
        else:
            return False
        return any(isinstance(value, str) and line_text == value.casefold() for value in candidates)

    @classmethod
    def _is_bare_data_secret_token(cls, payload: bytes, finding: dict[str, Any]) -> bool:
        if finding.get("secret_type") not in PASSIVE_DATA_SECRET_TYPES:
            return False
        line_parts = cls._finding_line_parts(payload, finding)
        if line_parts is None:
            return False
        line, position = line_parts
        length = finding.get("length")
        if not isinstance(length, int) or length <= 0 or position + length > len(line):
            return False
        stripped = line.strip()
        if not stripped or b"@" in stripped or b":" in stripped or b"=" in stripped:
            return False
        return line[position : position + length].strip() == stripped

    @staticmethod
    def _passive_data_basic_token_decodes_to_credentials(token: bytes) -> bool:
        return SecretsDetector._basic_auth_token_decodes_to_credentials(token.decode("ascii"))

    @staticmethod
    def _passive_data_bearer_token_is_credential_like(token: bytes) -> bool:
        unpadded_token = token.rstrip(b"=")
        return any(byte in PASSIVE_DATA_BEARER_TOKEN_MARKER_BYTES for byte in unpadded_token)

    @classmethod
    def _passive_data_bare_secret_finding_is_actionable(cls, payload: bytes, finding: dict[str, Any]) -> bool:
        line = cls._finding_line(payload, finding)
        if line is None:
            return False

        secret_type = finding.get("secret_type")
        if secret_type == "Basic Auth Credentials":
            match = PASSIVE_DATA_BASIC_AUTH_LINE_PATTERN.match(line)
            return match is not None and cls._passive_data_basic_token_decodes_to_credentials(match.group("token"))
        if secret_type == "Bearer Token":
            match = PASSIVE_DATA_BEARER_AUTH_LINE_PATTERN.match(line)
            return match is not None and cls._passive_data_bearer_token_is_credential_like(match.group("token"))
        return True

    @classmethod
    def _passive_data_auth_line_has_existing_finding(
        cls,
        payload: bytes,
        findings: list[dict[str, Any]],
        *,
        line_start: int,
        line_end: int,
        secret_type: str,
    ) -> bool:
        for finding in findings:
            if finding.get("secret_type") != secret_type:
                continue
            position = finding.get("position")
            if isinstance(position, int) and line_start <= position <= line_end:
                return True
            line = cls._finding_line(payload, finding)
            if line is not None and payload[line_start:line_end].strip() == line:
                return True
        return False

    @classmethod
    def _passive_data_auth_line_secret_findings(
        cls,
        path: str,
        payload: bytes,
        findings: list[dict[str, Any]],
        *,
        max_findings: int,
    ) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
        if not cls._is_passive_data_sidecar(path):
            return [], None

        passive_findings: list[dict[str, Any]] = []
        for match in PASSIVE_DATA_BASIC_AUTH_LINE_PATTERN.finditer(payload):
            token = match.group("token")
            if not cls._passive_data_basic_token_decodes_to_credentials(token):
                continue

            secret_type = "Basic Auth Credentials"
            line_start, line_end, _line_number = cls._documentation_line_bounds(payload, match.start())
            if cls._passive_data_auth_line_has_existing_finding(
                payload,
                findings + passive_findings,
                line_start=line_start,
                line_end=line_end,
                secret_type=secret_type,
            ):
                continue

            token_position = match.start("token")
            if len(findings) + len(passive_findings) >= max_findings:
                return passive_findings, {
                    "type": DETECTOR_FINDING_LIMIT_TYPE,
                    "detector": "secrets",
                    "severity": "INFO",
                    "message": "Embedded secret findings exceeded the configured reporting limit",
                    "max_findings": max_findings,
                    "analysis_incomplete": True,
                    "context": path,
                }
            passive_findings.append(
                {
                    "type": "embedded_secret",
                    "severity": "CRITICAL",
                    "secret_type": secret_type,
                    "position": token_position,
                    "length": len(token),
                    "confidence": 0.8,
                    "pattern": "passive_data_auth_line",
                    "redacted_value": "Basic <redacted>",
                    "message": f"{secret_type} detected in passive data sidecar (confidence: 80%)",
                    "context": f"{path} pos:{token_position}",
                    "recommendation": f"Remove {secret_type} from model data immediately",
                    "passive_data_sidecar": True,
                }
            )
        return passive_findings, None

    @classmethod
    def _is_isolated_tokenizer_vocabulary_cc_finding(cls, payload: bytes, finding: dict[str, Any]) -> bool:
        if finding.get("type") != "cc_pattern":
            return False

        pattern = finding.get("pattern")
        if not isinstance(pattern, str) or pattern.casefold() not in TOKENIZER_VOCABULARY_OMITTABLE_CC_PATTERNS:
            return False

        line = cls._finding_line(payload, finding)
        if line is None or not cls._is_tokenizer_vocabulary_token_line(line):
            return False

        try:
            line_text = line.decode("utf-8")
        except UnicodeDecodeError:
            return False

        for prefix in ("##", "\u0120", "\u2581"):
            if line_text.startswith(prefix):
                line_text = line_text[len(prefix) :]
                break
        for suffix in TOKENIZER_VOCABULARY_SUBWORD_SUFFIXES:
            if line_text.endswith(suffix):
                line_text = line_text[: -len(suffix)]
                break

        pattern_text = pattern.casefold()
        normalized_line_text = line_text.casefold()
        return normalized_line_text in {pattern_text, f"{pattern_text}s"}

    @classmethod
    def _retarget_or_omit_tokenizer_vocabulary_cc_finding(
        cls,
        payload: bytes,
        finding: dict[str, Any],
    ) -> tuple[dict[str, Any] | None, bool]:
        pattern = finding.get("pattern")
        if finding.get("type") != "cc_pattern" or not isinstance(pattern, str):
            return finding, False

        pattern_text = pattern.casefold()
        if pattern_text not in TOKENIZER_VOCABULARY_OMITTABLE_CC_PATTERNS:
            return finding, False

        pattern_bytes = pattern_text.encode()
        lowered_payload = payload.lower()
        search_start = 0
        occurrences_examined = 0
        while True:
            position = lowered_payload.find(pattern_bytes, search_start)
            if position < 0:
                return None, False
            occurrences_examined += 1
            if occurrences_examined > MAX_TOKENIZER_VOCABULARY_CC_RETARGET_OCCURRENCES:
                return finding, True
            candidate = {**finding, "position": position}
            if cls._is_isolated_tokenizer_vocabulary_cc_finding(payload, candidate):
                search_start = position + len(pattern_bytes)
                continue
            candidate.pop("snippet", None)
            return candidate, False

    @staticmethod
    def _all_network_candidate_lines_are_bare(payload: bytes) -> bool:
        for line in payload.splitlines():
            stripped = line.strip()
            if not stripped or not any(pattern.search(stripped) for pattern in BARE_NETWORK_TOKEN_PATTERNS):
                continue
            if b"@" in stripped or not any(pattern.fullmatch(stripped) for pattern in BARE_NETWORK_TOKEN_PATTERNS):
                return False
        return True

    @staticmethod
    def _documentation_position_is_in_bibliography_entry(
        payload: bytes,
        line_start: int,
        position: int | None = None,
    ) -> bool:
        context_end = line_start if position is None else min(max(position, 0), len(payload))
        context_start = max(0, context_end - MAX_TEXT_FINDING_CONTEXT_BYTES)
        context = payload[context_start:context_end]
        entry_start = None
        for match in DOCUMENTATION_BIBLIOGRAPHY_ENTRY_START_PATTERN.finditer(context):
            entry_start = match.start()
        if entry_start is None:
            return False
        entry_context = context[entry_start:]
        return entry_context.count(b"{") > entry_context.count(b"}")

    @staticmethod
    def _documentation_bibliography_entry_closes_after_position(payload: bytes, position: int) -> bool:
        position = min(max(position, 0), len(payload))
        context_start = max(0, position - MAX_TEXT_FINDING_CONTEXT_BYTES)
        context_end = min(len(payload), position + MAX_TEXT_FINDING_CONTEXT_BYTES)
        context = payload[context_start:context_end]
        relative_position = position - context_start
        entry_start = None
        for match in DOCUMENTATION_BIBLIOGRAPHY_ENTRY_START_PATTERN.finditer(context[:relative_position]):
            entry_start = match.start()
        if entry_start is None:
            return False
        entry_context = context[entry_start:]
        return entry_context.count(b"{") <= entry_context.count(b"}")

    @classmethod
    def _documentation_position_is_in_passive_bibliography_field(cls, payload: bytes, position: int) -> bool:
        position = min(max(position, 0), len(payload))
        line_start = payload.rfind(b"\n", 0, position) + 1
        line_end = payload.find(b"\n", position)
        if line_end < 0:
            line_end = len(payload)
        if not cls._documentation_position_is_in_bibliography_entry(payload, line_start, position):
            return False
        line = payload[line_start:line_end]
        line_position = position - line_start
        field_match = DOCUMENTATION_BIBLIOGRAPHY_FIELD_PREFIX_PATTERN.search(line[:line_position])
        if field_match is None:
            return False
        field = field_match.group("field").lower()
        if field == b"url":
            delimiter = field_match.group("delimiter")
            return delimiter not in {b'"', b"'"} or cls._documentation_bibliography_entry_closes_after_position(
                payload,
                position,
            )
        return field in DOCUMENTATION_PASSIVE_BIBLIOGRAPHY_FIELDS

    @classmethod
    def _documentation_bibliography_url_field_is_passive(
        cls,
        payload: bytes,
        line_start: int,
        line: bytes,
        position: int,
    ) -> bool:
        url_match = DOCUMENTATION_BIBLIOGRAPHY_URL_FIELD_PREFIX_PATTERN.search(line[:position])
        if url_match is None or not cls._documentation_position_is_in_bibliography_entry(
            payload,
            line_start,
            line_start + position,
        ):
            return False
        delimiter = url_match.group("delimiter")
        return delimiter not in {b'"', b"'"} or cls._documentation_bibliography_entry_closes_after_position(
            payload,
            line_start + position,
        )

    @classmethod
    def _documentation_network_token_lines_are_passive(cls, payload: bytes) -> bool:
        line_start = 0
        while line_start <= len(payload):
            line_end = payload.find(b"\n", line_start)
            if line_end < 0:
                line_end = len(payload)
            line = payload[line_start:line_end]
            url_spans: list[tuple[int, int]] = []
            for match in BARE_NETWORK_URL_TOKEN_PATTERN.finditer(line):
                url_spans.append((match.start(), match.end()))
                if cls._documentation_bibliography_url_field_is_passive(payload, line_start, line, match.start()):
                    continue
                absolute_position = line_start + match.start()
                if (
                    cls._documentation_line_is_code_shaped(
                        line,
                        match.start(),
                    )
                    or cls._documentation_multiline_return_contains_position(
                        payload,
                        absolute_position,
                    )
                    or cls._documentation_open_call_contains_position(payload, absolute_position)
                    or cls._documentation_multiline_literal_contains_position(payload, absolute_position)
                    or cls._documentation_nested_config_contains_position(payload, absolute_position)
                ):
                    return False
            for pattern in (
                BARE_NETWORK_IPV4_TOKEN_PATTERN,
                BARE_NETWORK_IPV6_TOKEN_PATTERN,
                BARE_NETWORK_DOMAIN_TOKEN_PATTERN,
            ):
                for match in pattern.finditer(line):
                    if any(start <= match.start() < end for start, end in url_spans):
                        continue
                    if pattern is BARE_NETWORK_DOMAIN_TOKEN_PATTERN:
                        if cls._documentation_position_is_in_passive_bibliography_field(
                            payload,
                            line_start + match.start(),
                        ):
                            continue
                        before = line[match.start() - 1 : match.start()] if match.start() > 0 else b""
                        after = line[match.end() : match.end() + 1]
                        if before in {b".", b"_"} or after in {b".", b"_"}:
                            continue
                        tld = match.group().rsplit(b".", 1)[-1].decode("utf-8", errors="ignore").casefold()
                        if tld not in DOCUMENTATION_BARE_DOMAIN_TLDS:
                            if DOCUMENTATION_CONFIG_MAPPING_PREFIX_PATTERN.search(line[: match.start()]) is not None:
                                return False
                            continue
                    absolute_position = line_start + match.start()
                    if (
                        cls._documentation_line_is_code_shaped(
                            line,
                            match.start(),
                        )
                        or cls._documentation_multiline_return_contains_position(
                            payload,
                            absolute_position,
                        )
                        or cls._documentation_open_call_contains_position(payload, absolute_position)
                        or cls._documentation_multiline_literal_contains_position(payload, absolute_position)
                        or cls._documentation_nested_config_contains_position(payload, absolute_position)
                    ):
                        return False
            if line_end == len(payload):
                break
            line_start = line_end + 1
        return True

    @staticmethod
    def _split_detector_finding_limit(
        findings: list[dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
        limit_finding = next(
            (finding for finding in findings if finding.get("type") == DETECTOR_FINDING_LIMIT_TYPE),
            None,
        )
        return (
            [finding for finding in findings if finding.get("type") != DETECTOR_FINDING_LIMIT_TYPE],
            limit_finding,
        )

    @classmethod
    def _passive_network_reporting_limit(
        cls,
        path: str,
        payload: bytes,
        findings: list[dict[str, Any]],
        finding_limit: dict[str, Any],
    ) -> bool:
        if finding_limit.get(
            "truncated_finding_type"
        ) == "endpoint_redaction_classification" and cls._is_documentation_sidecar(path):
            return all(
                cls._sidecar_network_finding_is_informational(path, payload, finding) for finding in findings
            ) and cls._documentation_network_token_lines_are_passive(payload)
        if finding_limit.get("truncated_finding_type") not in PASSIVE_NETWORK_FINDING_TYPES:
            return False
        truncated_finding = finding_limit.get("truncated_finding")
        return (
            cls._is_passive_data_sidecar(path)
            and all(finding.get("severity") == "INFO" for finding in findings)
            and isinstance(truncated_finding, dict)
            and cls._is_bare_data_network_token(payload, truncated_finding)
            and cls._all_network_candidate_lines_are_bare(payload)
        )

    @classmethod
    def _sidecar_network_finding_is_informational(
        cls,
        path: str,
        payload: bytes,
        finding: dict[str, Any],
    ) -> bool:
        if cls._is_documentation_sidecar(path):
            finding_type = finding.get("type")
            position = finding.get("position")
            if isinstance(position, int) and cls._documentation_comment_contains_position(payload, position):
                return True
            filename = os.path.basename(path).lower()
            if (
                cls._is_readme_documentation_filename(filename) or cls._is_model_card_documentation_filename(filename)
            ) and cls._documentation_package_version_is_informational(payload, finding):
                return True
            return (
                (
                    finding_type in PASSIVE_NETWORK_FINDING_TYPES
                    and not cls._documentation_finding_is_actionable(payload, finding)
                )
                or (
                    finding_type == "network_function"
                    and cls._documentation_network_function_is_prose(payload, finding)
                )
                or (finding_type == "network_library" and cls._documentation_network_library_is_prose(payload, finding))
                or (finding_type == "cc_pattern" and cls._documentation_cc_finding_is_benign_prose(payload, finding))
                or (
                    finding_type == "suspicious_port" and not cls._documentation_finding_is_actionable(payload, finding)
                )
            )
        if cls._is_passive_data_sidecar(path):
            return cls._is_bare_data_network_token(payload, finding)
        return finding.get("type") in PASSIVE_NETWORK_FINDING_TYPES and cls._standard_requirements_network_finding(
            path,
            payload,
            finding,
        )

    @staticmethod
    def _documentation_line_bounds_lookup(
        payload: bytes,
        positions: list[int],
    ) -> dict[int, tuple[int, int, int]]:
        normalized_positions = sorted({min(max(position, 0), len(payload)) for position in positions})
        lookup: dict[int, tuple[int, int, int]] = {}
        if not normalized_positions:
            return lookup

        line_start = 0
        line_number = 1
        position_index = 0
        while position_index < len(normalized_positions):
            line_end = payload.find(b"\n", line_start)
            if line_end < 0:
                line_end = len(payload)
            while position_index < len(normalized_positions) and normalized_positions[position_index] <= line_end:
                lookup[normalized_positions[position_index]] = (line_start, line_end, line_number)
                position_index += 1
            if line_end == len(payload):
                break
            line_start = line_end + 1
            line_number += 1
        return lookup

    @staticmethod
    def _documentation_line_bounds(
        payload: bytes,
        position: int,
        line_lookup: dict[int, tuple[int, int, int]] | None = None,
    ) -> tuple[int, int, int]:
        position = min(max(position, 0), len(payload))
        if line_lookup is not None and (line_bounds := line_lookup.get(position)) is not None:
            return line_bounds
        line_start = payload.rfind(b"\n", 0, position) + 1
        line_end = payload.find(b"\n", position)
        if line_end < 0:
            line_end = len(payload)
        return line_start, line_end, payload.count(b"\n", 0, line_start) + 1

    @staticmethod
    def _normalize_documentation_network_evidence_value(value: str) -> str:
        normalized = value.strip().lstrip(DOCUMENTATION_NETWORK_EVIDENCE_LEADING_DELIMITERS)
        normalized = normalized.rstrip(DOCUMENTATION_NETWORK_EVIDENCE_TRAILING_DELIMITERS)
        if "://" in normalized:
            normalized = redact_url_for_finding(normalized)
        try:
            parsed = urlsplit(normalized)
        except ValueError:
            return normalized.casefold()
        if parsed.scheme and parsed.netloc:
            return urlunsplit(
                (
                    parsed.scheme.casefold(),
                    parsed.netloc.casefold(),
                    parsed.path,
                    parsed.query,
                    parsed.fragment,
                )
            )
        return normalized.casefold()

    @classmethod
    def _documentation_network_evidence_from_span(
        cls,
        payload: bytes,
        span_start: int,
        span_end: int,
        *,
        kind: str,
        value: str,
        line_lookup: dict[int, tuple[int, int, int]] | None = None,
    ) -> dict[str, Any]:
        line_start, _line_end, line_number = cls._documentation_line_bounds(payload, span_start, line_lookup)
        column = len(payload[line_start:span_start].decode("utf-8", errors="replace")) + 1
        return {
            "kind": kind,
            "value": cls._normalize_documentation_network_evidence_value(value),
            "line": line_number,
            "column": column,
            "span_start": span_start,
            "span_end": span_end,
        }

    @staticmethod
    def _documentation_url_scheme_byte_is_valid(value: int, *, first: bool = False) -> bool:
        return (
            (65 <= value <= 90)
            or (97 <= value <= 122)
            or (not first and ((48 <= value <= 57) or value in {ord("+"), ord("."), ord("-")}))
        )

    @classmethod
    def _documentation_url_scheme_is_valid(cls, scheme: bytes) -> bool:
        return (
            bool(scheme)
            and cls._documentation_url_scheme_byte_is_valid(scheme[0], first=True)
            and all(cls._documentation_url_scheme_byte_is_valid(value) for value in scheme[1:])
        )

    @staticmethod
    def _documentation_url_candidate_end(payload: bytes, span_start: int, line_end: int) -> int | None:
        scan_end = min(line_end, span_start + MAX_TEXT_FINDING_CONTEXT_BYTES)
        span_end = span_start
        while span_end < scan_end and payload[span_end] not in DOCUMENTATION_NETWORK_URL_BOUNDARY_BYTES:
            span_end += 1
        if (
            span_end == scan_end
            and span_end < line_end
            and payload[span_end] not in DOCUMENTATION_NETWORK_URL_BOUNDARY_BYTES
        ):
            return None
        return span_end

    @classmethod
    def _documentation_bare_url_span_at_position(
        cls,
        payload: bytes,
        position: int,
        line_start: int,
        line_end: int,
    ) -> tuple[int, int] | None:
        if line_start >= line_end:
            return None
        position = min(max(position, line_start), line_end - 1)
        separator_start = max(line_start, position - MAX_TEXT_FINDING_CONTEXT_BYTES)
        separator_end = min(
            line_end,
            position + DOCUMENTATION_NETWORK_URL_MAX_SCHEME_BYTES + len(b"://"),
        )
        matching_spans: list[tuple[int, int]] = []
        seen_starts: set[int] = set()
        separator = payload.find(b"://", separator_start, separator_end)
        while separator >= 0:
            candidate_starts: list[int] = []
            if position <= separator and cls._documentation_url_scheme_is_valid(payload[position:separator]):
                candidate_starts.append(position)

            scheme_start = separator - 1
            minimum_scheme_start = max(line_start, separator - DOCUMENTATION_NETWORK_URL_MAX_SCHEME_BYTES)
            while scheme_start > minimum_scheme_start and cls._documentation_url_scheme_byte_is_valid(
                payload[scheme_start - 1]
            ):
                scheme_start -= 1
            if cls._documentation_url_scheme_is_valid(payload[scheme_start:separator]):
                candidate_starts.append(scheme_start)

            for candidate_start in candidate_starts:
                if candidate_start in seen_starts:
                    continue
                seen_starts.add(candidate_start)
                candidate_end = cls._documentation_url_candidate_end(payload, candidate_start, line_end)
                if (
                    candidate_end is not None
                    and candidate_start <= position < candidate_end
                    and BARE_NETWORK_URL_TOKEN_PATTERN.fullmatch(payload[candidate_start:candidate_end]) is not None
                ):
                    matching_spans.append((candidate_start, candidate_end))
            separator = payload.find(b"://", separator + len(b"://"), separator_end)
        if not matching_spans:
            return None
        return min(matching_spans, key=lambda span: (span[1] - span[0], -span[0]))

    @classmethod
    def _documentation_url_evidence_at_position(
        cls,
        payload: bytes,
        position: int,
        line_lookup: dict[int, tuple[int, int, int]] | None = None,
    ) -> dict[str, Any] | None:
        line_start, line_end, _line_number = cls._documentation_line_bounds(payload, position, line_lookup)
        span = cls._documentation_bare_url_span_at_position(payload, position, line_start, line_end)
        if span is not None:
            span_start, span_end = span
            raw_value = payload[span_start:span_end].decode("utf-8", errors="ignore")
            return cls._documentation_network_evidence_from_span(
                payload,
                span_start,
                span_end,
                kind="url",
                value=redact_url_for_finding(raw_value),
                line_lookup=line_lookup,
            )
        return None

    @classmethod
    def _documentation_network_command_evidence(
        cls,
        payload: bytes,
        finding: dict[str, Any],
        line_lookup: dict[int, tuple[int, int, int]] | None = None,
    ) -> dict[str, Any] | None:
        position = finding.get("position")
        destination = finding.get("destination")
        if not isinstance(position, int) or not isinstance(destination, str) or not destination:
            return None

        url_evidence = cls._documentation_url_evidence_at_position(payload, position, line_lookup)
        if url_evidence is not None:
            return url_evidence

        line_start, line_end, _line_number = cls._documentation_line_bounds(payload, position, line_lookup)
        line_position = position - line_start
        destination_match = DOCUMENTATION_NETWORK_DESTINATION_TOKEN_PATTERN.match(
            payload[line_start:line_end], line_position
        )
        if destination_match is None:
            return None
        return cls._documentation_network_evidence_from_span(
            payload,
            line_start + destination_match.start(),
            line_start + destination_match.end(),
            kind="destination",
            value=destination,
            line_lookup=line_lookup,
        )

    @staticmethod
    def _documentation_network_command_is_correlatable(finding: dict[str, Any]) -> bool:
        return finding.get("type") == "network_command" and finding.get("command_type") == "git_clone"

    @classmethod
    def _documentation_network_command_evidences(
        cls,
        payload: bytes,
        findings: list[dict[str, Any]],
        line_lookup: dict[int, tuple[int, int, int]],
    ) -> list[dict[str, Any]]:
        return [
            evidence
            for finding in findings
            if cls._documentation_network_command_is_correlatable(finding)
            if (evidence := cls._documentation_network_command_evidence(payload, finding, line_lookup)) is not None
        ]

    @staticmethod
    def _documentation_network_evidence_at_position(
        evidences: list[dict[str, Any]],
        position: int,
    ) -> dict[str, Any] | None:
        matching_evidences = [
            evidence for evidence in evidences if int(evidence["span_start"]) <= position < int(evidence["span_end"])
        ]
        if not matching_evidences:
            return None
        return min(matching_evidences, key=lambda evidence: int(evidence["span_end"]) - int(evidence["span_start"]))

    @classmethod
    def _documentation_network_finding_evidence(
        cls,
        payload: bytes,
        finding: dict[str, Any],
        command_evidences: list[dict[str, Any]],
        line_lookup: dict[int, tuple[int, int, int]],
    ) -> dict[str, Any] | None:
        finding_type = finding.get("type")
        position = finding.get("position")
        if finding_type not in CORRELATABLE_DOCUMENTATION_NETWORK_FINDING_TYPES or not isinstance(position, int):
            return None
        if finding_type == "network_command" and not cls._documentation_network_command_is_correlatable(finding):
            return None

        url_evidence = cls._documentation_url_evidence_at_position(payload, position, line_lookup)
        if url_evidence is not None:
            if finding_type in {"cloud_storage_url", "url_detected"}:
                finding_url = finding.get("url")
                if isinstance(finding_url, str) and finding_url:
                    normalized_finding_url = cls._normalize_documentation_network_evidence_value(finding_url)
                    if str(url_evidence["value"]) != normalized_finding_url:
                        return cls._documentation_network_evidence_from_span(
                            payload,
                            position,
                            position + len(finding_url.encode("utf-8", errors="ignore")),
                            kind="url",
                            value=finding_url,
                            line_lookup=line_lookup,
                        )
            return url_evidence

        command_evidence = cls._documentation_network_evidence_at_position(command_evidences, position)
        if command_evidence is not None:
            return command_evidence

        if finding_type == "network_command":
            return cls._documentation_network_command_evidence(payload, finding, line_lookup)

        if finding_type in {"domain", "domain_name"}:
            value = finding.get("domain")
            kind = "host"
        elif finding_type in {"ipv4_address", "ipv6_address"}:
            value = finding.get("ip")
            kind = "ip"
        elif finding_type in {"cloud_storage_url", "url_detected"}:
            value = finding.get("url")
            kind = "url"
        else:
            return None

        if not isinstance(value, str) or not value:
            return None
        return cls._documentation_network_evidence_from_span(
            payload,
            position,
            position + len(value.encode("utf-8", errors="ignore")),
            kind=kind,
            value=value,
            line_lookup=line_lookup,
        )

    @staticmethod
    def _documentation_network_finding_sort_key(finding: dict[str, Any], original_index: int) -> tuple[int, int, int]:
        severity = str(finding.get("severity", "WARNING")).upper()
        finding_type = str(finding.get("type", ""))
        return (
            DOCUMENTATION_NETWORK_FINDING_PRIORITY.get(finding_type, 0),
            DOCUMENTATION_NETWORK_FINDING_SEVERITY_RANK.get(
                severity,
                DOCUMENTATION_NETWORK_FINDING_SEVERITY_RANK["WARNING"],
            ),
            -original_index,
        )

    @staticmethod
    def _highest_documentation_network_severity(findings: list[dict[str, Any]]) -> str:
        return max(
            (str(finding.get("severity", "WARNING")).upper() for finding in findings),
            key=lambda severity: DOCUMENTATION_NETWORK_FINDING_SEVERITY_RANK.get(
                severity,
                DOCUMENTATION_NETWORK_FINDING_SEVERITY_RANK["WARNING"],
            ),
        )

    @staticmethod
    def _documentation_network_evidence_fingerprint(evidence: dict[str, Any]) -> str:
        material = "|".join(
            (
                "text-documentation-network-v1",
                str(evidence["line"]),
                str(evidence["column"]),
                str(evidence["kind"]),
                str(evidence["value"]),
            )
        )
        digest = hashlib.sha256(material.encode("utf-8")).hexdigest()[:24]
        return f"text-doc-network:{digest}"

    @staticmethod
    def _documentation_network_related_finding(finding: dict[str, Any]) -> dict[str, Any]:
        return {
            key: finding[key]
            for key in (
                "type",
                "severity",
                "message",
                "position",
                "url",
                "domain",
                "ip",
                "destination",
                "command_type",
                "provider",
            )
            if key in finding
        }

    @classmethod
    def _annotate_documentation_network_finding(
        cls,
        finding: dict[str, Any],
        evidence: dict[str, Any],
        related_findings: list[dict[str, Any]],
    ) -> dict[str, Any]:
        fingerprint = cls._documentation_network_evidence_fingerprint(evidence)
        annotated = {
            **finding,
            "line": evidence["line"],
            "column": evidence["column"],
            "evidence_fingerprint": fingerprint,
            "evidence_location": {
                "line": evidence["line"],
                "column": evidence["column"],
                "span_start": evidence["span_start"],
                "span_end": evidence["span_end"],
            },
            "normalized_evidence": {
                "kind": evidence["kind"],
                "value": evidence["value"],
            },
        }
        if related_findings:
            annotated["deduplicated_related_findings"] = related_findings
            annotated["deduplicated_related_count"] = len(related_findings)
        return annotated

    @classmethod
    def _deduplicate_documentation_network_findings(
        cls,
        path: str,
        payload: bytes,
        findings: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        if not cls._is_documentation_sidecar(path):
            return findings

        finding_positions = [position for finding in findings if isinstance((position := finding.get("position")), int)]
        line_lookup = cls._documentation_line_bounds_lookup(payload, finding_positions)
        command_evidences = cls._documentation_network_command_evidences(payload, findings, line_lookup)
        grouped: dict[tuple[int, int, str, str], list[tuple[int, dict[str, Any], dict[str, Any]]]] = {}
        ordered_items: list[tuple[str, int | tuple[int, int, str, str]]] = []
        standalone: dict[int, dict[str, Any]] = {}
        for index, finding in enumerate(findings):
            evidence = cls._documentation_network_finding_evidence(payload, finding, command_evidences, line_lookup)
            if evidence is None:
                ordered_items.append(("standalone", index))
                standalone[index] = finding
                continue
            key = (
                int(evidence["line"]),
                int(evidence["column"]),
                str(evidence["kind"]),
                str(evidence["value"]),
            )
            if key not in grouped:
                ordered_items.append(("group", key))
            grouped.setdefault(key, []).append((index, finding, evidence))

        deduplicated: list[dict[str, Any]] = []
        emitted_keys: set[tuple[int, int, str, str]] = set()
        for item_type, item_value in ordered_items:
            if item_type == "standalone":
                assert isinstance(item_value, int)
                deduplicated.append(standalone[item_value])
                continue
            assert not isinstance(item_value, int)
            key = item_value
            if key in emitted_keys:
                continue
            emitted_keys.add(key)
            entries = grouped[key]
            representative_index, representative, representative_evidence = max(
                entries,
                key=lambda entry: cls._documentation_network_finding_sort_key(entry[1], entry[0]),
            )
            severity = cls._highest_documentation_network_severity([entry[1] for entry in entries])
            if str(representative.get("severity", "WARNING")).upper() != severity:
                representative = {**representative, "severity": severity}
            related_findings = [
                cls._documentation_network_related_finding(related)
                for related_index, related, _evidence in entries
                if related_index != representative_index
            ]
            deduplicated.append(
                cls._annotate_documentation_network_finding(
                    representative,
                    representative_evidence,
                    related_findings,
                )
            )
        return deduplicated

    @classmethod
    def _downgrade_sidecar_network_findings(
        cls,
        path: str,
        payload: bytes,
        findings: list[dict[str, Any]],
    ) -> tuple[list[dict[str, Any]], bool, set[str]]:
        classified_findings: list[dict[str, Any]] = []
        classification_incomplete = False
        classification_limit_sources: set[str] = set()
        remaining_occurrences = MAX_DOCUMENTATION_FINDING_RETARGET_OCCURRENCES
        documentation_sidecar = cls._is_documentation_sidecar(path)
        lowered_payload = payload.lower() if documentation_sidecar else b""
        tokenizer_vocabulary_sidecar = cls._has_line_oriented_tokenizer_vocabulary_evidence(path, payload)
        last_retargetable_index = max(
            (index for index, finding in enumerate(findings) if cls._documentation_finding_tokens(finding)),
            default=-1,
        )
        for index, finding in enumerate(findings):
            retarget_incomplete = False
            if documentation_sidecar:
                finding, retarget_incomplete, remaining_occurrences = cls._retarget_documentation_finding(
                    payload,
                    lowered_payload,
                    finding,
                    remaining_occurrences,
                    index == last_retargetable_index,
                )
                classification_incomplete = classification_incomplete or retarget_incomplete
                if retarget_incomplete:
                    classification_limit_sources.add("documentation")
            if tokenizer_vocabulary_sidecar:
                retargeted_finding, tokenizer_retarget_incomplete = (
                    cls._retarget_or_omit_tokenizer_vocabulary_cc_finding(payload, finding)
                )
                classification_incomplete = classification_incomplete or tokenizer_retarget_incomplete
                retarget_incomplete = retarget_incomplete or tokenizer_retarget_incomplete
                if tokenizer_retarget_incomplete:
                    classification_limit_sources.add("tokenizer_vocabulary")
                if retargeted_finding is None:
                    continue
                finding = retargeted_finding
            if not retarget_incomplete and cls._sidecar_network_finding_is_informational(path, payload, finding):
                finding = {**finding, "severity": "INFO"}
            classified_findings.append(finding)
        return classified_findings, classification_incomplete, classification_limit_sources

    @classmethod
    def _downgrade_sidecar_secret_findings(
        cls,
        path: str,
        payload: bytes,
        findings: list[dict[str, Any]],
        *,
        max_findings: int,
    ) -> tuple[list[dict[str, Any]], dict[str, Any] | None]:
        if not cls._is_passive_data_sidecar(path):
            return findings, None

        findings = [
            finding
            for finding in findings
            if not cls._is_bare_data_secret_token(payload, finding)
            or cls._passive_data_bare_secret_finding_is_actionable(payload, finding)
        ]
        # Whole-line Basic/Bearer matches in passive sidecars can be real credentials.
        passive_findings, finding_limit = cls._passive_data_auth_line_secret_findings(
            path,
            payload,
            findings,
            max_findings=max_findings,
        )
        return findings + passive_findings, finding_limit

    @staticmethod
    def _is_unreadable_path_result(result: ScanResult) -> bool:
        return any(check.name == "Path Readable" and check.status == CheckStatus.FAILED for check in result.checks)

    @staticmethod
    def _finish_metadata_read_failure(result: ScanResult, path: str, error: OSError) -> ScanResult:
        mark_inconclusive_scan_result(result, "text_metadata_read_failed")
        mark_operational_scan_error(result, "text_metadata_read_failed")
        result.add_check(
            name="Text File Metadata Read",
            passed=False,
            message=f"Unable to inspect text file metadata: {error!s}",
            severity=IssueSeverity.INFO,
            location=path,
            details={
                "exception": str(error),
                "exception_type": type(error).__name__,
                "analysis_incomplete": True,
                "scan_outcome_reason": "text_metadata_read_failed",
            },
        )
        result.finish(success=False)
        return result

    @staticmethod
    def _mark_content_security_scan_incomplete(
        result: ScanResult,
        path: str,
        *,
        reason: str,
        message: str,
        details: dict[str, Any],
    ) -> None:
        mark_inconclusive_scan_result(result, reason)
        mark_operational_scan_error(result, reason)
        result.add_check(
            name="Text Content Security Coverage",
            passed=False,
            message=message,
            severity=IssueSeverity.INFO,
            location=path,
            details={
                **details,
                "analysis_incomplete": True,
                "scan_outcome_reason": reason,
            },
        )

    def _run_content_security_checks(self, path: str, result: ScanResult, file_size: int) -> int:
        check_secrets = self._get_bool_config("check_secrets", True)
        check_network = self._get_bool_config("check_network_comm", True)
        if not check_secrets:
            result.metadata.setdefault("disabled_checks", []).append("Embedded Secrets Detection")
        if not check_network:
            result.metadata.setdefault("disabled_checks", []).append("Network Communication Detection")
        if not check_secrets and not check_network:
            return 0

        read_limit = self._get_content_security_scan_bytes()
        max_findings = self._get_content_security_max_findings()
        try:
            with open(path, "rb") as file_obj:
                payload = file_obj.read(read_limit + 1)
        except OSError as error:
            self._mark_content_security_scan_incomplete(
                result,
                path,
                reason="text_content_read_failed",
                message=f"Unable to read text content for security detectors: {error!s}",
                details={
                    "exception": str(error),
                    "exception_type": type(error).__name__,
                    "file_size": file_size,
                    "read_limit": read_limit,
                },
            )
            return 0

        truncated = len(payload) > read_limit
        inspected_payload = payload[:read_limit]
        inspected_bytes = len(inspected_payload)

        detector_incomplete = False
        if check_secrets:
            try:
                secret_findings = self.collect_embedded_secret_findings(
                    inspected_payload,
                    path,
                    raise_on_error=True,
                    max_findings=max_findings,
                )
                secret_findings, finding_limit = self._split_detector_finding_limit(secret_findings)
                secret_findings, passive_finding_limit = self._downgrade_sidecar_secret_findings(
                    path,
                    inspected_payload,
                    secret_findings,
                    max_findings=max_findings,
                )
                if finding_limit is None:
                    finding_limit = passive_finding_limit
                if secret_findings or not truncated:
                    self.add_embedded_secret_findings(secret_findings, result, context=path)
                if finding_limit is not None:
                    detector_incomplete = True
                    self._mark_content_security_scan_incomplete(
                        result,
                        path,
                        reason=TEXT_CONTENT_SECURITY_FINDING_LIMIT_REASON,
                        message="Embedded secret findings exceeded the configured reporting limit",
                        details=finding_limit,
                    )
            except Exception as error:
                detector_incomplete = True
                redacted_error = redact_untrusted_error_message(error)
                self._mark_content_security_scan_incomplete(
                    result,
                    path,
                    reason=TEXT_CONTENT_SECURITY_DETECTOR_FAILED_REASON,
                    message=f"Embedded secret detector failed for text content: {redacted_error}",
                    details={
                        "detector": "secrets",
                        "exception": redacted_error,
                        "exception_type": type(error).__name__,
                    },
                )

        if check_network:
            try:
                network_findings = self.collect_network_communication_findings(
                    inspected_payload,
                    path,
                    raise_on_error=True,
                    max_findings=max_findings,
                )
                network_findings, finding_limit = self._split_detector_finding_limit(network_findings)
                network_findings, classification_incomplete, classification_limit_sources = (
                    self._downgrade_sidecar_network_findings(
                        path,
                        inspected_payload,
                        network_findings,
                    )
                )
                network_findings = self._deduplicate_documentation_network_findings(
                    path,
                    inspected_payload,
                    network_findings,
                )
                if network_findings or not truncated:
                    self.add_network_communication_findings(network_findings, result, context=path)
                if classification_incomplete:
                    detector_incomplete = True
                    classification_limits = {
                        "documentation": MAX_DOCUMENTATION_FINDING_RETARGET_OCCURRENCES,
                        "tokenizer_vocabulary": MAX_TOKENIZER_VOCABULARY_CC_RETARGET_OCCURRENCES,
                    }
                    active_classification_limits = [
                        classification_limits[source]
                        for source in classification_limit_sources
                        if source in classification_limits
                    ]
                    classification_details: dict[str, Any] = {
                        "classification_limit_sources": sorted(classification_limit_sources),
                    }
                    if len(active_classification_limits) == 1:
                        classification_details["max_classification_occurrences"] = active_classification_limits[0]
                    if "documentation" in classification_limit_sources:
                        classification_details["max_documentation_classification_occurrences"] = (
                            MAX_DOCUMENTATION_FINDING_RETARGET_OCCURRENCES
                        )
                    if "tokenizer_vocabulary" in classification_limit_sources:
                        classification_details["max_tokenizer_vocabulary_cc_retarget_occurrences"] = (
                            MAX_TOKENIZER_VOCABULARY_CC_RETARGET_OCCURRENCES
                        )
                    self._mark_content_security_scan_incomplete(
                        result,
                        path,
                        reason=TEXT_CONTENT_SECURITY_CLASSIFICATION_LIMIT_REASON,
                        message="Text network finding classification exceeded the work limit",
                        details=classification_details,
                    )
                if finding_limit is not None:
                    if self._passive_network_reporting_limit(
                        path,
                        inspected_payload,
                        network_findings,
                        finding_limit,
                    ):
                        result.add_check(
                            name="Network Communication Reporting Limit",
                            passed=False,
                            message="Passive network references exceeded the reporting limit",
                            severity=IssueSeverity.INFO,
                            location=path,
                            details={
                                **finding_limit,
                                "analysis_incomplete": False,
                                "reporting_incomplete": True,
                            },
                        )
                    else:
                        detector_incomplete = True
                        self._mark_content_security_scan_incomplete(
                            result,
                            path,
                            reason=TEXT_CONTENT_SECURITY_FINDING_LIMIT_REASON,
                            message="Network communication findings exceeded the configured reporting limit",
                            details=finding_limit,
                        )
            except Exception as error:
                detector_incomplete = True
                redacted_error = redact_untrusted_error_message(error)
                self._mark_content_security_scan_incomplete(
                    result,
                    path,
                    reason=TEXT_CONTENT_SECURITY_DETECTOR_FAILED_REASON,
                    message=f"Network communication detector failed for text content: {redacted_error}",
                    details={
                        "detector": "network_communication",
                        "exception": redacted_error,
                        "exception_type": type(error).__name__,
                    },
                )

        if truncated:
            self._mark_content_security_scan_incomplete(
                result,
                path,
                reason=TEXT_CONTENT_SECURITY_SCAN_INCOMPLETE_REASON,
                message=f"Text content security scan truncated at configured limit ({read_limit} bytes)",
                details={
                    "file_size": file_size,
                    "read_limit": read_limit,
                    "inspected_bytes": inspected_bytes,
                    "enabled_detectors": [
                        detector
                        for detector, enabled in (("secrets", check_secrets), ("network_communication", check_network))
                        if enabled
                    ],
                },
            )
        elif not detector_incomplete:
            result.add_check(
                name="Text Content Security Coverage",
                passed=True,
                message="Text content security detectors completed",
                location=path,
                details={
                    "file_size": file_size,
                    "read_limit": read_limit,
                    "inspected_bytes": inspected_bytes,
                },
            )

        return inspected_bytes

    def scan(self, path: str) -> ScanResult:
        """Scan a text file for security issues."""
        result = self._create_scan_result_after_preflight(path, check_size_limit=False)
        if not result.success:
            if self._is_unreadable_path_result(result):
                return self._finish_metadata_read_failure(
                    self._create_result(),
                    path,
                    PermissionError(f"Path is not readable: {path}"),
                )
            return result

        try:
            # Get file size
            file_size = self._get_file_size(path)
            result.metadata["file_size"] = file_size

            # Check if file exceeds expected size for text files
            if file_size > 100 * 1024 * 1024:  # 100MB
                result.add_check(
                    name="File Size Check",
                    passed=False,
                    message=f"Unusually large text file: {file_size / (1024 * 1024):.1f}MB",
                    rule_code="S902",
                    severity=IssueSeverity.WARNING,
                    location=path,
                    details={"file_size": file_size},
                )
            else:
                result.add_check(
                    name="File Size Check",
                    passed=True,
                    message="Text file size is reasonable",
                    location=path,
                    details={"file_size": file_size},
                    rule_code=None,  # Passing check
                )

            filename = os.path.basename(path).lower()

            # Identify file type - these are informational checks, not security issues
            if filename in DOCUMENTATION_TEXT_FILENAMES:
                result.add_check(
                    name="File Type Identification",
                    passed=True,
                    message="Model documentation file",
                    location=path,
                    details={"file_type": "documentation"},
                    rule_code=None,  # Passing check
                )
            elif filename in ["vocab.txt", "vocabulary.txt", "tokens.txt", "tokenizer.txt", "merges.txt"]:
                result.add_check(
                    name="File Type Identification",
                    passed=True,
                    message="Tokenizer vocabulary file",
                    location=path,
                    details={"file_type": "vocabulary"},
                    rule_code=None,  # Passing check
                )
            elif filename in ["labels.txt", "classes.txt"]:
                result.add_check(
                    name="File Type Identification",
                    passed=True,
                    message="Classification labels file",
                    location=path,
                    details={"file_type": "labels"},
                    rule_code=None,  # Passing check
                )
            elif filename in ["license.txt", "license.md"]:
                result.add_check(
                    name="File Type Identification",
                    passed=True,
                    message="License file",
                    location=path,
                    details={"file_type": "license"},
                    rule_code=None,  # Passing check
                )
            elif filename == "requirements.txt":
                # Could scan for suspicious dependencies in the future
                result.add_check(
                    name="File Type Identification",
                    passed=True,
                    message="Python requirements file",
                    location=path,
                    details={"file_type": "requirements"},
                    rule_code=None,  # Passing check
                )
            else:
                result.add_check(
                    name="File Type Identification",
                    passed=True,
                    message="ML-related text file",
                    location=path,
                    details={"file_type": "text"},
                    rule_code=None,  # Passing check
                )

            result.bytes_scanned = self._run_content_security_checks(path, result, file_size)
            result.finish(
                success=result.metadata.get("scan_outcome") != INCONCLUSIVE_SCAN_OUTCOME and not result.has_errors,
            )

        except OSError as e:
            self._finish_metadata_read_failure(result, path, e)
        except Exception as e:
            result.add_check(
                name="Text File Scan",
                passed=False,
                message=f"Error scanning text file: {e!s}",
                severity=IssueSeverity.CRITICAL,
                location=path,
                details={"error": str(e)},
                rule_code="S902",
            )
            result.finish(success=False)

        return result
